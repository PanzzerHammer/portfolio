/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Util;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.KeyStroke;

/**
 *
 * @author Panzzer
 */
public abstract class KeyBinding {
    
    public static void addKeyBinding (JComponent comp, int keyCode, String idCode, ActionListener actionListener){
        InputMap im = comp.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap ap = comp.getActionMap();
        
        im.put(KeyStroke.getKeyStroke(keyCode, 0, false), idCode);
        
        ap.put(idCode, new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actionListener.actionPerformed(e);
            }
        });
    }
    
    public static void addKeyBindingWithEvent (JComponent comp, int keyCode,int keyEvent, String idCode, ActionListener actionListener){
        InputMap im = comp.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap ap = comp.getActionMap();
        
        im.put(KeyStroke.getKeyStroke(keyCode, keyEvent, false), idCode);
        
        ap.put(idCode, new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actionListener.actionPerformed(e);
            }
        });
    }
     
}
