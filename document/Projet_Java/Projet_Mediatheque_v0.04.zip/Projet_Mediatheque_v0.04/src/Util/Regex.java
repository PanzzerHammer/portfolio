/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

/**
 *
 * @author Panzzer
 */
public abstract class Regex {

    public static boolean noCaracSpec(String text) {
        boolean test = false;
        Pattern pattern = Pattern.compile("[^\\w\\s\\-_áàâäãåçéèêëíìîïñóòôöõúùûüýÿæœÁÀÂÄÃÅÇÉÈÊËÍÌÎÏÑÓÒÔÖÕÚÙÛÜÝŸÆŒ]");
        Matcher matcher = pattern.matcher(text);
        if (matcher.find()) {
            JOptionPane.showMessageDialog(null, "Veuillez entrer un texte sans caratères spéciaux, seul - et _ sont autorisés", "Erreur", JOptionPane.WARNING_MESSAGE);
        } else {
            test = true;
        }

        return test;
    }
    
    public static boolean  numberWith2Decimal(String text){
        boolean test = false;
        Pattern pattern = Pattern.compile("^\\d+\\.?\\d{0,2}$");
        Matcher matcher = pattern.matcher(text);
        if (matcher.find()) {
            test = true;
        }
        return test;
    }
    
   public static boolean  numberSize4(String text){
        boolean test = false;
        Pattern pattern = Pattern.compile("^\\d{4}$");
        Matcher matcher = pattern.matcher(text);
        if (matcher.find()) {
            test = true;
        }
        return test;
    } 
    
   public static boolean  number(String text){
        boolean test = false;
        Pattern pattern = Pattern.compile("^\\d+$");
        Matcher matcher = pattern.matcher(text);
        if (matcher.find()) {
            test = true;
        }
        return test;
    }
}
