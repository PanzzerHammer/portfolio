/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Class;

import Util.MySqlConnect;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Panzzer
 */
public class Commande {

    private int idCommande;
    private String dateCommande;
    private String login;
    private double total;
    private PreparedStatement pst;
    private ResultSet rs;
    private ArrayList<Commande> listeCommande;

    public Commande(int idCommande, String dateCommande, String login, double total) {
        this.idCommande = idCommande;
        this.dateCommande = dateCommande;
        this.login = login;
        this.total = total;
    }

    public Commande() {

    }

    public int getIdCommande() {
        return idCommande;
    }

    public String getDateCommande() {
        return dateCommande;
    }

    public String getLogin() {
        return login;
    }

    public double getTotal() {
        return total;
    }

    public ArrayList<Commande> getListeCommande() {
        return listeCommande;
    }

    public void recupCommandeDB() {
        String request = "SELECT * FROM v_info_commande ";
        MySqlConnect.testConn();
        if (MySqlConnect.conn != null) {
            try {
                pst = MySqlConnect.conn.prepareStatement(request);
                rs = pst.executeQuery();
                this.listeCommande = new ArrayList<>();
                while (rs.next()) {
                    int idCommandeR = rs.getInt("id_commande");
                    java.sql.Time dbSqlTime = rs.getTime("date_commande");
                    java.sql.Date dbSqlDate = rs.getDate("date_commande");
                    java.util.Date dbSqlTimeConverted = new java.util.Date(dbSqlTime.getTime());
                    java.util.Date dbSqlDateConverted = new java.util.Date(dbSqlDate.getTime());
                    String dateCommandeR = new SimpleDateFormat("yyyy.MM.dd").format(dbSqlDateConverted)+" à "+ new SimpleDateFormat("HH:mm:ss").format(dbSqlTimeConverted);
                    String loginR = rs.getString("login");
                    double totalR = rs.getDouble("total");
                    this.listeCommande.add(new Commande(idCommandeR, dateCommandeR, loginR, totalR));
                }
                pst.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "problème avec recupCommandeDB()" + ex.getMessage(), "Problème rencontré",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

}
