/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Util;

import Class.Autre;
import java.util.ArrayList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author Panzzer
 */
public abstract class TextFilter {

    public static void addTextFilterTable(JTable table, JTextField textfield) {
        TableRowSorter<TableModel> rowSorter = new TableRowSorter<>(table.getModel());
        table.setRowSorter(rowSorter);
        textfield.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent de) {
                String text = textfield.getText();
                if (text.trim().length() == 0) {
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }

            @Override
            public void removeUpdate(DocumentEvent de) {
                String text = textfield.getText();
                if (text.trim().length() == 0) {
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }

            @Override
            public void changedUpdate(DocumentEvent de) {
                String text = textfield.getText();
                if (text.trim().length() == 0) {
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }
        });
    }

    public static void addTextFilterComboBox(DefaultComboBoxModel model, JTextField textfield, ArrayList<Autre> autre) {
        textfield.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent de) {
                model.removeAllElements();
                String text = textfield.getText();
                for (int i = 0; i < autre.size(); i++) {
                    if (autre.get(i).getName().toLowerCase().contains(text.toLowerCase())) {
                        model.addElement(autre.get(i));
                    }
                }
            }

            @Override
            public void removeUpdate(DocumentEvent de) {
                model.removeAllElements();
                String text = textfield.getText();
                for (int i = 0; i < autre.size(); i++) {
                    if (autre.get(i).getName().toLowerCase().contains(text.toLowerCase())) {
                        model.addElement(autre.get(i));
                    }
                }
            }

            @Override
            public void changedUpdate(DocumentEvent de) {
                model.removeAllElements();
                String text = textfield.getText();
                for (int i = 0; i < autre.size(); i++) {
                    if (autre.get(i).getName().toLowerCase().contains(text.toLowerCase())) {
                        model.addElement(autre.get(i));
                    }
                }
            }
        });   
    }
    
    public static void addTextFilterList(DefaultListModel model, JTextField textfield, ArrayList<Autre> autre) {
        textfield.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent de) {
                model.removeAllElements();
                String text = textfield.getText();
                for (int i = 0; i < autre.size(); i++) {
                    if (autre.get(i).getName().toLowerCase().contains(text.toLowerCase())) {
                        model.addElement(autre.get(i));
                    }
                }
            }

            @Override
            public void removeUpdate(DocumentEvent de) {
                model.removeAllElements();
                String text = textfield.getText();
                for (int i = 0; i < autre.size(); i++) {
                    if (autre.get(i).getName().toLowerCase().contains(text.toLowerCase())) {
                        model.addElement(autre.get(i));
                    }
                }
            }

            @Override
            public void changedUpdate(DocumentEvent de) {
                model.removeAllElements();
                String text = textfield.getText();
                for (int i = 0; i < autre.size(); i++) {
                    if (autre.get(i).getName().toLowerCase().contains(text.toLowerCase())) {
                        model.addElement(autre.get(i));
                    }
                }
            }
        });
    }
}
