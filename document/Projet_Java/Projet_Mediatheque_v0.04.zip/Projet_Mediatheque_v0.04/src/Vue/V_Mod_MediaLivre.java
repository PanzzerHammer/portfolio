/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;

import Class.Autre;
import Class.Media_Livre;
import Control.C_Autre;
import Control.C_Media_Livre;
import Util.Regex;
import java.util.ArrayList;
import javax.swing.DefaultComboBoxModel;
import Util.TextFilter;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

/**
 *
 * @author Panzzer
 */
public class V_Mod_MediaLivre extends javax.swing.JFrame {

    private final V_Home home;
    private final C_Autre autre;
    private final C_Media_Livre livre;
    private int idLivre = 0;
    private double prixLivre = 0;

    /**
     * Creates new form V_AddMod_MediaLivre
     *
     * @param autre
     * @param livre
     * @param home
     */
    public V_Mod_MediaLivre(C_Autre autre, C_Media_Livre livre, V_Home home) {
        initComponents();
        this.autre = autre;
        this.livre = livre;
        this.home = home;
    }

    public void setIdLivre(int idLivre) {
        this.idLivre = idLivre;
    }

    public void setComboBox() {
        ArrayList<Autre> listEditeur = autre.getListAutre(0);
        ArrayList<Autre> listFormat = autre.getListAutre(3);
        DefaultComboBoxModel modelComboEditeur = new DefaultComboBoxModel();
        DefaultComboBoxModel modelComboFormat = new DefaultComboBoxModel();
        for (int i = 0; i < listEditeur.size(); i++) {
            modelComboEditeur.addElement(listEditeur.get(i));
        }
        comboBoxEditeur.setModel(modelComboEditeur);
        for (int i = 0; i < listFormat.size(); i++) {
            modelComboFormat.addElement(listFormat.get(i));
        }
        comboBoxFormat.setModel(modelComboFormat);
        TextFilter.addTextFilterComboBox(modelComboEditeur, textFilterEditeur, listEditeur);
        TextFilter.addTextFilterComboBox(modelComboFormat, textFilterFormat, listFormat);
    }

    public void setList() {
        setListAuteur();
        setListGenre();
    }

    public void setListAuteur() {
        String requestAuteur = " JOIN p_auteurs ON personnes.id_personne = p_auteurs.id_auteur WHERE p_auteurs.id_media_livre = " + this.idLivre;
        String requestAuteurFull = " WHERE personnes.id_personne NOT IN "
                + "(SELECT personnes.id_personne FROM personnes "
                + "JOIN p_auteurs ON personnes.id_personne = p_auteurs.id_auteur "
                + "WHERE p_auteurs.id_media_livre =  " + this.idLivre + " )";
        ArrayList<Autre> arrayAuteur = autre.getListAutreMinusArticle(7, requestAuteur);
        ArrayList<Autre> arrayAuteurFull = autre.getListAutreMinusArticle(7, requestAuteurFull);
        DefaultListModel modelListAuteur = new DefaultListModel();
        DefaultListModel modelListAuteurFull = new DefaultListModel();
        for (int i = 0; i < arrayAuteur.size(); i++) {
            modelListAuteur.addElement(arrayAuteur.get(i));
        }
        listAuteur.setModel(modelListAuteur);
        for (int i = 0; i < arrayAuteurFull.size(); i++) {
            modelListAuteurFull.addElement(arrayAuteurFull.get(i));
        }
        listAuteurFull.setModel(modelListAuteurFull);
        TextFilter.addTextFilterList(modelListAuteurFull, textFilterAuteur, arrayAuteurFull);
    }

    public void setListGenre() {
        String requestGenre = " JOIN media_livre_genres ON genres_livre.id_genre = media_livre_genres.id_genre_livre "
                + "WHERE media_livre_genres.id_media_livre = " + this.idLivre;
        String requestGenreFull = " WHERE genres_livre.id_genre NOT IN "
                + "(SELECT genres_livre.id_genre FROM genres_livre "
                + "JOIN media_livre_genres ON genres_livre.id_genre = media_livre_genres.id_genre_livre "
                + "WHERE media_livre_genres.id_media_livre = " + this.idLivre + " )";
        ArrayList<Autre> arrayGenre = autre.getListAutreMinusArticle(6, requestGenre);
        ArrayList<Autre> arrayGenreFull = autre.getListAutreMinusArticle(6, requestGenreFull);
        DefaultListModel modelListGenre = new DefaultListModel();
        DefaultListModel modelListGenreFull = new DefaultListModel();
        for (int i = 0; i < arrayGenre.size(); i++) {
            modelListGenre.addElement(arrayGenre.get(i));
        }
        listGenre.setModel(modelListGenre);
        for (int i = 0; i < arrayGenreFull.size(); i++) {
            modelListGenreFull.addElement(arrayGenreFull.get(i));
        }
        listGenreFull.setModel(modelListGenreFull);
        TextFilter.addTextFilterList(modelListGenreFull, textFilterGenre, arrayGenreFull);
    }

    public void setLivre() {
        if (this.livre.getLivre(this.idLivre)) {
            Media_Livre livreInfo = this.livre.getInstanceLivre().getLivre();
            textTitre.setText(livreInfo.getTitre());
            textPrix.setText(String.valueOf(livreInfo.getPrix()));
            this.prixLivre = livreInfo.getPrix();
            String etat = livreInfo.getEtat();
            radButAcceptable.setSelected(true);
            if ("b".equals(etat)) {
                radButBloque.setSelected(true);
            } else if ("w".equals(etat)) {
                radButEnAttente.setSelected(true);
            }
            textAnnee.setText(String.valueOf(livreInfo.getAnnee()));
            textStock.setText(String.valueOf(livreInfo.getStock()));
            int support = livreInfo.getIdSupport();
            if (support == 1) {
                radButPhysique.setSelected(true);
            } else if (support == 2) {
                radButNumerique.setSelected(true);
            }
            textISBN.setText(livreInfo.getISBN());

            int idEditeur = livreInfo.getIdEditeur();
            DefaultComboBoxModel modelComboEditeur = (DefaultComboBoxModel) comboBoxEditeur.getModel();
            Autre editTest = new Autre(idEditeur, "");
            int indexEditeur = modelComboEditeur.getIndexOf(editTest);
            comboBoxEditeur.setSelectedIndex(indexEditeur);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        groupButEtat = new javax.swing.ButtonGroup();
        groupButSupport = new javax.swing.ButtonGroup();
        jPanBackground = new javax.swing.JPanel();
        labTitreFenetre = new javax.swing.JLabel();
        textTitre = new javax.swing.JTextField();
        labTitre = new javax.swing.JLabel();
        radButAcceptable = new javax.swing.JRadioButton();
        radButBloque = new javax.swing.JRadioButton();
        radButEnAttente = new javax.swing.JRadioButton();
        textISBN = new javax.swing.JTextField();
        labPrix = new javax.swing.JLabel();
        radButPhysique = new javax.swing.JRadioButton();
        radButNumerique = new javax.swing.JRadioButton();
        comboBoxEditeur = new javax.swing.JComboBox<>();
        comboBoxFormat = new javax.swing.JComboBox<>();
        labEtat = new javax.swing.JLabel();
        labAnnee = new javax.swing.JLabel();
        labStock = new javax.swing.JLabel();
        lzbSupport = new javax.swing.JLabel();
        labISBN = new javax.swing.JLabel();
        labEditeur = new javax.swing.JLabel();
        labFormat = new javax.swing.JLabel();
        labAuteur = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listAuteur = new javax.swing.JList<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        listGenre = new javax.swing.JList<>();
        labGenre = new javax.swing.JLabel();
        butAddAuteur = new javax.swing.JButton();
        butSupAuteur = new javax.swing.JButton();
        butAddGenre = new javax.swing.JButton();
        butSupGenre = new javax.swing.JButton();
        textFilterEditeur = new javax.swing.JTextField();
        textFilterFormat = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        listAuteurFull = new javax.swing.JList<>();
        textFilterAuteur = new javax.swing.JTextField();
        textFilterGenre = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        listGenreFull = new javax.swing.JList<>();
        butFermer = new javax.swing.JButton();
        butModifier = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        textPrix = new javax.swing.JTextField();
        textAnnee = new javax.swing.JTextField();
        textStock = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        labTitreFenetre.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        labTitreFenetre.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labTitreFenetre.setText("Modifier un Livre");

        labTitre.setText("Titre :");

        groupButEtat.add(radButAcceptable);
        radButAcceptable.setSelected(true);
        radButAcceptable.setText("acceptable");

        groupButEtat.add(radButBloque);
        radButBloque.setText("bloqué");

        groupButEtat.add(radButEnAttente);
        radButEnAttente.setText("en attente");

        labPrix.setText("Prix :");

        groupButSupport.add(radButPhysique);
        radButPhysique.setSelected(true);
        radButPhysique.setText("physique");

        groupButSupport.add(radButNumerique);
        radButNumerique.setText("numérique");

        labEtat.setText("Etat :");

        labAnnee.setText("Année :");

        labStock.setText("Stock :");

        lzbSupport.setText("Support :");

        labISBN.setText("ISBN :");

        labEditeur.setText("Editeur :");

        labFormat.setText("Format :");

        labAuteur.setText("Auteur(s) :");

        listAuteur.setModel(new DefaultListModel());
        listAuteur.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        listAuteur.setFocusable(false);
        jScrollPane1.setViewportView(listAuteur);

        listGenre.setModel(new DefaultListModel());
        listGenre.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        listGenre.setFocusable(false);
        jScrollPane2.setViewportView(listGenre);

        labGenre.setText("Genre(s) :");

        butAddAuteur.setText("Ajouter");
        butAddAuteur.setFocusable(false);
        butAddAuteur.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butAddAuteurActionPerformed(evt);
            }
        });

        butSupAuteur.setText("Enlever");
        butSupAuteur.setFocusable(false);
        butSupAuteur.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butSupAuteurActionPerformed(evt);
            }
        });

        butAddGenre.setText("Ajouter");
        butAddGenre.setFocusable(false);
        butAddGenre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butAddGenreActionPerformed(evt);
            }
        });

        butSupGenre.setText("Enlever");
        butSupGenre.setFocusable(false);
        butSupGenre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butSupGenreActionPerformed(evt);
            }
        });

        listAuteurFull.setModel(new DefaultListModel());
        listAuteurFull.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        listAuteurFull.setFocusable(false);
        jScrollPane3.setViewportView(listAuteurFull);

        listGenreFull.setModel(new DefaultListModel());
        listGenreFull.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        listGenreFull.setFocusable(false);
        jScrollPane4.setViewportView(listGenreFull);

        butFermer.setText("Fermer");
        butFermer.setFocusable(false);
        butFermer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butFermerActionPerformed(evt);
            }
        });

        butModifier.setText("Modifier");
        butModifier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butModifierActionPerformed(evt);
            }
        });

        jSeparator1.setForeground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanBackgroundLayout = new javax.swing.GroupLayout(jPanBackground);
        jPanBackground.setLayout(jPanBackgroundLayout);
        jPanBackgroundLayout.setHorizontalGroup(
            jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanBackgroundLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(labTitreFenetre, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanBackgroundLayout.createSequentialGroup()
                        .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(labPrix, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(labEtat, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(labStock, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lzbSupport, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(labISBN, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(labEditeur, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(labAuteur, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(labAnnee, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(labTitre, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(labFormat, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(labGenre, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanBackgroundLayout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanBackgroundLayout.createSequentialGroup()
                                        .addComponent(radButPhysique)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(radButNumerique))
                                    .addGroup(jPanBackgroundLayout.createSequentialGroup()
                                        .addComponent(radButAcceptable)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(radButBloque)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(radButEnAttente)))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(textISBN)
                            .addComponent(textTitre)
                            .addGroup(jPanBackgroundLayout.createSequentialGroup()
                                .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                                    .addComponent(comboBoxFormat, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(comboBoxEditeur, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanBackgroundLayout.createSequentialGroup()
                                        .addGap(12, 12, 12)
                                        .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(textFilterEditeur)
                                            .addComponent(textFilterFormat)))
                                    .addGroup(jPanBackgroundLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanBackgroundLayout.createSequentialGroup()
                                                .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addComponent(butAddGenre, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(butSupGenre))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanBackgroundLayout.createSequentialGroup()
                                                .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(butSupAuteur)
                                                    .addComponent(butAddAuteur, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                                                    .addComponent(textFilterAuteur, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE))))
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanBackgroundLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(textFilterGenre, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(butFermer, javax.swing.GroupLayout.Alignment.TRAILING)))))
                            .addComponent(textPrix)
                            .addComponent(textAnnee)
                            .addComponent(textStock))))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanBackgroundLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(butModifier)
                .addGap(183, 183, 183))
            .addComponent(jSeparator1)
        );
        jPanBackgroundLayout.setVerticalGroup(
            jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanBackgroundLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(labTitreFenetre)
                .addGap(26, 26, 26)
                .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labTitre)
                    .addComponent(textTitre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labPrix)
                    .addComponent(textPrix, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labEtat)
                    .addComponent(radButAcceptable)
                    .addComponent(radButBloque)
                    .addComponent(radButEnAttente))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labAnnee)
                    .addComponent(textAnnee, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labStock)
                    .addComponent(textStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lzbSupport)
                    .addComponent(radButPhysique)
                    .addComponent(radButNumerique))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labISBN)
                    .addComponent(textISBN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textFilterEditeur, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(labEditeur)
                        .addComponent(comboBoxEditeur, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textFilterFormat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(labFormat)
                        .addComponent(comboBoxFormat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(butModifier)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(labAuteur, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanBackgroundLayout.createSequentialGroup()
                        .addComponent(textFilterAuteur, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanBackgroundLayout.createSequentialGroup()
                                .addComponent(butAddAuteur)
                                .addGap(9, 9, 9)
                                .addComponent(butSupAuteur))
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanBackgroundLayout.createSequentialGroup()
                        .addComponent(textFilterGenre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanBackgroundLayout.createSequentialGroup()
                                .addComponent(butAddGenre)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(butSupGenre))))
                    .addComponent(labGenre)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(butFermer)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanBackground, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanBackground, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void butAddAuteurActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butAddAuteurActionPerformed
        if (listAuteurFull.getSelectedIndex() != -1) {
            Autre auteur = listAuteurFull.getSelectedValue();
            if (autre.addAutreArticle(4, auteur.getId(), this.idLivre)) {
                setListAuteur();
            }
        }
    }//GEN-LAST:event_butAddAuteurActionPerformed

    private void butSupAuteurActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butSupAuteurActionPerformed
        if (listAuteur.getSelectedIndex() != -1) {
            Autre auteur = listAuteur.getSelectedValue();
            if (autre.supAutreArticle(4, auteur.getId(), this.idLivre)) {
                setListAuteur();
            }
        }
    }//GEN-LAST:event_butSupAuteurActionPerformed

    private void butAddGenreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butAddGenreActionPerformed
        if (listGenreFull.getSelectedIndex() != -1) {
            Autre genre = listGenreFull.getSelectedValue();
            if (autre.addAutreArticle(2, this.idLivre, genre.getId())) {
                setListGenre();
            }
        }
    }//GEN-LAST:event_butAddGenreActionPerformed

    private void butSupGenreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butSupGenreActionPerformed
        if (listGenre.getSelectedIndex() != -1) {
            Autre genre = listGenre.getSelectedValue();
            if (autre.supAutreArticle(2, this.idLivre, genre.getId())) {
                setListGenre();
            }
        }
    }//GEN-LAST:event_butSupGenreActionPerformed

    private void butModifierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butModifierActionPerformed
        if (verifChampMediaLivre()) {
            if (JOptionPane.showConfirmDialog(this, "Êtes vous sur de vouloir modifier ce Livre", "Modification", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
                getChampMediaLivre();
            }
        }
    }//GEN-LAST:event_butModifierActionPerformed

    private void butFermerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butFermerActionPerformed
        this.dispose();
    }//GEN-LAST:event_butFermerActionPerformed

    private boolean verifChampMediaLivre() {
        boolean test = false;
        String titre = textTitre.getText();
        String prix = textPrix.getText();
        String annee = textAnnee.getText();
        String stock = textStock.getText();
        String isbn = textISBN.getText();
        if (!"".equals(titre) && !"".equals(prix) && !"".equals(annee) && !"".equals(stock) && !"".equals(isbn)) {
            if (Regex.noCaracSpec(titre) && Regex.noCaracSpec(isbn)) {
                if (Regex.numberWith2Decimal(prix)) {
                    if (Regex.numberSize4(annee)) {
                        if (Regex.number(stock)) {
                            test = true;
                        } else {
                            JOptionPane.showMessageDialog(this, "Veuillez saisir un nombre valide pour le stock", "Erreur", JOptionPane.WARNING_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Veuillez saisir une année valide", "Erreur", JOptionPane.WARNING_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Veuillez saisir un nombre valide pour le prix", "Erreur", JOptionPane.WARNING_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez renseigner tout les champs", "Erreur", JOptionPane.WARNING_MESSAGE);
        }
        return test;
    }

    private void getChampMediaLivre() {
        String titre = textTitre.getText();
        Double prix = Double.parseDouble(textPrix.getText());
        String etat = "a";
        if (radButBloque.isSelected()) {
            etat = "b";
        }
        if (radButEnAttente.isSelected()) {
            etat = "w";
        }
        int annee = Integer.parseInt(textAnnee.getText());
        int stock = Integer.parseInt(textStock.getText());
        int support = 1;
        if (radButNumerique.isSelected()) {
            support = 2;
        }
        String isbn = textISBN.getText();
        Autre editeur = (Autre) comboBoxEditeur.getSelectedItem();
        Autre format = (Autre) comboBoxFormat.getSelectedItem();
        if (livre.modLivre(this.idLivre, titre, prix, etat, annee, stock, support, isbn, editeur.getId(), format.getId())) {
            JOptionPane.showMessageDialog(this, "Le Livre à été corectement modifier", "Modification", JOptionPane.INFORMATION_MESSAGE);
            setLivre();
            setFilterOptionHome();
        }
    }

    public void setFilterOptionHome() {
        int support;
        int etat;
        int stock = Integer.parseInt(textStock.getText());
        if (radButPhysique.isSelected()) {
            support = 1;
        } else {
            support = 2;
        }
        if (radButAcceptable.isSelected()) {
            etat = 1;
        } else if (radButBloque.isSelected()) {
            etat = 2;
        } else {
            etat = 3;
        }
        home.setFilter(1, support, etat, stock);
        home.filtreArticle();
    }

    /**
     * @param args the command line arguments
     */
//    public static void main(String args[]) {
//        /* Set the Nimbus look and feel */
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(V_Mod_MediaLivre.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(V_Mod_MediaLivre.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(V_Mod_MediaLivre.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(V_Mod_MediaLivre.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//
//        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new V_Mod_MediaLivre().setVisible(true);
//            }
//        });
//    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton butAddAuteur;
    private javax.swing.JButton butAddGenre;
    private javax.swing.JButton butFermer;
    private javax.swing.JButton butModifier;
    private javax.swing.JButton butSupAuteur;
    private javax.swing.JButton butSupGenre;
    private javax.swing.JComboBox<Autre> comboBoxEditeur;
    private javax.swing.JComboBox<Autre> comboBoxFormat;
    private javax.swing.ButtonGroup groupButEtat;
    private javax.swing.ButtonGroup groupButSupport;
    private javax.swing.JPanel jPanBackground;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel labAnnee;
    private javax.swing.JLabel labAuteur;
    private javax.swing.JLabel labEditeur;
    private javax.swing.JLabel labEtat;
    private javax.swing.JLabel labFormat;
    private javax.swing.JLabel labGenre;
    private javax.swing.JLabel labISBN;
    private javax.swing.JLabel labPrix;
    private javax.swing.JLabel labStock;
    private javax.swing.JLabel labTitre;
    private javax.swing.JLabel labTitreFenetre;
    private javax.swing.JList<Autre> listAuteur;
    private javax.swing.JList<Autre> listAuteurFull;
    private javax.swing.JList<Autre> listGenre;
    private javax.swing.JList<Autre> listGenreFull;
    private javax.swing.JLabel lzbSupport;
    private javax.swing.JRadioButton radButAcceptable;
    private javax.swing.JRadioButton radButBloque;
    private javax.swing.JRadioButton radButEnAttente;
    private javax.swing.JRadioButton radButNumerique;
    private javax.swing.JRadioButton radButPhysique;
    private javax.swing.JTextField textAnnee;
    private javax.swing.JTextField textFilterAuteur;
    private javax.swing.JTextField textFilterEditeur;
    private javax.swing.JTextField textFilterFormat;
    private javax.swing.JTextField textFilterGenre;
    private javax.swing.JTextField textISBN;
    private javax.swing.JTextField textPrix;
    private javax.swing.JTextField textStock;
    private javax.swing.JTextField textTitre;
    // End of variables declaration//GEN-END:variables
}
