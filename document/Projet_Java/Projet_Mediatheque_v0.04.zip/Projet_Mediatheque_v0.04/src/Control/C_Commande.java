/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Class.Commande;
import java.util.ArrayList;

/**
 *
 * @author Panzzer
 */
public class C_Commande {
    
    private final Commande intanceCommande = new Commande();

    public C_Commande() {
    }

    public ArrayList<Commande> recupCommande(){
        this.intanceCommande.recupCommandeDB();
        return this.intanceCommande.getListeCommande();
    }
}
