/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Util;

import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author Panzzer
 */
public abstract class CenterColumnTable {
    
    public static void centerTableUser(JTable table) {     
        DefaultTableCellRenderer custom = new DefaultTableCellRenderer(); 
        custom.setHorizontalAlignment(JLabel.CENTER); 
        table.getColumnModel().getColumn(2).setCellRenderer(custom); 
        table.getColumnModel().getColumn(3).setCellRenderer(custom);
    }
    
    public static void centerTableArticle(JTable table) {
        DefaultTableCellRenderer custom = new DefaultTableCellRenderer(); 
        custom.setHorizontalAlignment(JLabel.CENTER);
        table.getColumnModel().getColumn(1).setCellRenderer(custom);
        table.getColumnModel().getColumn(2).setCellRenderer(custom);
        table.getColumnModel().getColumn(3).setCellRenderer(custom);
        table.getColumnModel().getColumn(4).setCellRenderer(custom);
        table.getColumnModel().getColumn(5).setCellRenderer(custom);
    }
    
     public static void centerTableCommande(JTable table) {
        DefaultTableCellRenderer custom = new DefaultTableCellRenderer(); 
        custom.setHorizontalAlignment(JLabel.CENTER);
        table.getColumnModel().getColumn(0).setCellRenderer(custom);
        table.getColumnModel().getColumn(1).setCellRenderer(custom);
        table.getColumnModel().getColumn(3).setCellRenderer(custom);
    }
    
}
