/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Class;

import Util.MySqlConnect;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Panzzer
 */
public class Autre implements Comparable<Autre> {
    // dans cette class je vais gérer les éditeurs formats et genres car dans le cas présent ils sont tous uniquement constitué d'une String
    // ce qui simplifie au lieu d'avoir une class pour chaque qui serais juste un copier coller, dans la pratique on doit faire une class pour
    // chaque 

    private int id = 0;
    private String name;
    private ArrayList<Autre> listAutre = new ArrayList<>();
    private PreparedStatement pst;
    private ResultSet rs;

    public Autre(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public Autre() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return this.getName();
    }

    public ArrayList<Autre> getListAutre() {
        return listAutre;
    }

    @Override // pour utiliser le .sort de Collection
    public int compareTo(Autre au) {
        int last = this.getName().compareTo(au.getName());
        return last;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + this.id;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Autre idTest = (Autre) obj;
        return idTest.id == this.id;
    }

    public void recupAutreDB(String nomTab, String idColonne, String nomColonne) {
        String request = "SELECT * FROM " + nomTab;
        MySqlConnect.testConn();
        if (MySqlConnect.conn != null) {
            try {
                pst = MySqlConnect.conn.prepareStatement(request);
                rs = pst.executeQuery();
                this.listAutre = new ArrayList<>();
                while (rs.next()) {
                    int idR = rs.getInt(idColonne);
                    String nameR = rs.getString(nomColonne);
                    this.listAutre.add(new Autre(idR, nameR));
                }
                pst.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "problème avec recupAutreDB()" + ex.getMessage(), "Problème rencontré",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public void recupAutreMinusArticleDB(String nomTab, String idColonne, String nomColonne, String tabJoin) {
        String request = "SELECT " + idColonne + "," + nomColonne + " FROM " + nomTab
                + tabJoin;
        MySqlConnect.testConn();
        if (MySqlConnect.conn != null) {
            try {
                pst = MySqlConnect.conn.prepareStatement(request);
                rs = pst.executeQuery();
                this.listAutre = new ArrayList<>();
                while (rs.next()) {
                    int idR = rs.getInt(idColonne);
                    String nameR = rs.getString(nomColonne);
                    this.listAutre.add(new Autre(idR, nameR));
                }
                pst.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "problème avec recupAutreMinusArticleDB()" + ex.getMessage(), "Problème rencontré",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public boolean modAutreDB(int id, String textModAutre, String request) {
        boolean testModif = false;
        MySqlConnect.testConn();
        if (MySqlConnect.conn != null) {
            try {
                pst = MySqlConnect.conn.prepareStatement(request);
                pst.setString(1, textModAutre);
                pst.setInt(2, id);
                pst.executeUpdate();
                testModif = true;
                pst.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "problème avec modAutreDB()" + ex.getMessage(), "Problème rencontré",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
        return testModif;
    }

    public boolean addAutreDB(String request) {
        boolean testAdd = false;
        MySqlConnect.testConn();
        if (MySqlConnect.conn != null) {
            try {
                pst = MySqlConnect.conn.prepareStatement(request);
                pst.executeUpdate();
                testAdd = true;
                pst.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "problème avec addAutreDB()" + ex.getMessage(), "Problème rencontré",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
        return testAdd;
    }

    public boolean supAutreDB(String request) {
        boolean testSup = false;
        MySqlConnect.testConn();
        if (MySqlConnect.conn != null) {
            try {
                pst = MySqlConnect.conn.prepareStatement(request);
                pst.executeUpdate();
                testSup = true;
                pst.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "problème avec supAutreDB()" + ex.getMessage(), "Problème rencontré",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
        return testSup;
    }
    
    public boolean addAutreArticleDB(String request, int id1, int id2){
        boolean testAdd = false;
        MySqlConnect.testConn();
        if (MySqlConnect.conn != null) {
            try {
                pst = MySqlConnect.conn.prepareStatement(request);
                pst.setInt(1, id1);
                pst.setInt(2, id2);
                pst.executeUpdate();
                testAdd = true;
                pst.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "problème avec addAutreArticleDB()" + ex.getMessage(), "Problème rencontré",
                        JOptionPane.ERROR_MESSAGE);
            }
        }       
        return testAdd;
    }
    
    public boolean supAutreArticleDB(String request, int id1, int id2){
        boolean testSup = false;
        MySqlConnect.testConn();
        if (MySqlConnect.conn != null) {
            try {
                pst = MySqlConnect.conn.prepareStatement(request);
                pst.setInt(1, id1);
                pst.setInt(2, id2);
                pst.executeUpdate();
                testSup = true;
                pst.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "problème avec supAutreArticleDB()" + ex.getMessage(), "Problème rencontré",
                        JOptionPane.ERROR_MESSAGE);
            }
        }       
        return testSup;
    }
}
