-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  mar. 05 juin 2018 à 10:59
-- Version du serveur :  5.7.19
-- Version de PHP :  7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `mediatheque`
--

DELIMITER $$
--
-- Procédures
--
DROP PROCEDURE IF EXISTS `insert_media_livre`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_media_livre` (IN `titre` VARCHAR(90) CHARSET utf8, IN `prix` DECIMAL(10,2), IN `etat` ENUM('a','w','b') CHARSET utf8, IN `annee` SMALLINT(5) UNSIGNED, IN `stock` INT(10) UNSIGNED, IN `id_support` INT(10) UNSIGNED, OUT `id_gen` BIGINT(20) UNSIGNED, IN `isbn` VARCHAR(60) CHARSET utf8, IN `id_editeur` INT(11) UNSIGNED, IN `id_format_livre` INT(10) UNSIGNED)  NO SQL
BEGIN
    
    INSERT INTO media (titre, prix, etat, annee, stock, id_support, type) 		VALUES (titre, prix, etat, annee, stock, id_support, 'livre');
	SELECT LAST_INSERT_ID() INTO id_gen;
    INSERT INTO media_livre (id_media, ISBN, id_editeur, id_format_livre)
    VALUES (id_gen, isbn, id_editeur, id_format_livre);
    
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

DROP TABLE IF EXISTS `commande`;
CREATE TABLE IF NOT EXISTS `commande` (
  `id_commande` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `date_commande` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_user` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id_commande`),
  KEY `id_user` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `commande`
--

INSERT INTO `commande` (`id_commande`, `date_commande`, `id_user`) VALUES
(1, '2018-05-25 14:57:55', 3),
(4, '2018-05-29 12:19:22', 3),
(5, '2018-05-29 12:28:12', 5),
(6, '2018-05-29 13:43:44', 5),
(7, '2018-05-29 14:33:46', 5),
(8, '2018-05-29 15:06:27', 6),
(9, '2018-05-30 09:02:38', 3),
(10, '2018-06-01 09:31:52', 6),
(11, '2018-06-05 08:50:45', 8),
(12, '2018-06-05 10:13:42', 5);

-- --------------------------------------------------------

--
-- Structure de la table `commande_ligne`
--

DROP TABLE IF EXISTS `commande_ligne`;
CREATE TABLE IF NOT EXISTS `commande_ligne` (
  `id_commande` bigint(20) UNSIGNED NOT NULL,
  `id_media` bigint(20) UNSIGNED NOT NULL,
  `qtx` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id_commande`,`id_media`),
  KEY `id_media` (`id_media`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `commande_ligne`
--

INSERT INTO `commande_ligne` (`id_commande`, `id_media`, `qtx`) VALUES
(1, 1, 3),
(1, 2, 5),
(4, 3, 1),
(4, 4, 1),
(5, 1, 1),
(5, 2, 1),
(6, 2, 2),
(7, 2, 1),
(7, 8, 1),
(8, 2, 1),
(9, 6, 1),
(9, 10, 1),
(10, 6, 1),
(10, 11, 1),
(11, 7, 2),
(12, 8, 1);

--
-- Déclencheurs `commande_ligne`
--
DROP TRIGGER IF EXISTS `after_ins_commande_ligne`;
DELIMITER $$
CREATE TRIGGER `after_ins_commande_ligne` AFTER INSERT ON `commande_ligne` FOR EACH ROW UPDATE media SET media.stock = (media.stock - NEW.qtx) WHERE media.id_media = NEW.id_media
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `edition`
--

DROP TABLE IF EXISTS `edition`;
CREATE TABLE IF NOT EXISTS `edition` (
  `id_editeur` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom_editeur` varchar(60) NOT NULL,
  PRIMARY KEY (`id_editeur`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `edition`
--

INSERT INTO `edition` (`id_editeur`, `nom_editeur`) VALUES
(1, 'Calmann-Levy'),
(5, 'Bourgois'),
(6, 'Albin Michel'),
(7, 'Le Livre de Poche');

--
-- Déclencheurs `edition`
--
DROP TRIGGER IF EXISTS `bef_ins_edition`;
DELIMITER $$
CREATE TRIGGER `bef_ins_edition` BEFORE INSERT ON `edition` FOR EACH ROW BEGIN

IF EXISTS (SELECT nom_editeur FROM edition WHERE nom_editeur = NEW.nom_editeur)
	THEN SET @msg = "Ajout impossible cet éditeur existe déjà";
	signal sqlstate '45003' set message_text = @msg;
END IF;

END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `bef_upd_edition`;
DELIMITER $$
CREATE TRIGGER `bef_upd_edition` BEFORE UPDATE ON `edition` FOR EACH ROW BEGIN

IF EXISTS (SELECT nom_editeur FROM edition WHERE nom_editeur = NEW.nom_editeur)
	THEN SET @msg = "Modification impossible cet éditeur existe déjà";
	signal sqlstate '45004' set message_text = @msg;
END IF;

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `format_audio`
--

DROP TABLE IF EXISTS `format_audio`;
CREATE TABLE IF NOT EXISTS `format_audio` (
  `id_format` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom_format` varchar(40) NOT NULL,
  PRIMARY KEY (`id_format`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `format_audio`
--

INSERT INTO `format_audio` (`id_format`, `nom_format`) VALUES
(1, 'vinyl'),
(2, 'CD'),
(3, 'MP3'),
(4, 'FLAC');

--
-- Déclencheurs `format_audio`
--
DROP TRIGGER IF EXISTS `bef_ins_format_audio`;
DELIMITER $$
CREATE TRIGGER `bef_ins_format_audio` BEFORE INSERT ON `format_audio` FOR EACH ROW BEGIN

IF EXISTS (SELECT nom_format FROM format_audio WHERE nom_format = NEW.nom_format)
	THEN SET @msg = "Ajout impossible ce format audio existe déjà";
	signal sqlstate '45005' set message_text = @msg;
END IF;

END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `bef_upd_format_audio`;
DELIMITER $$
CREATE TRIGGER `bef_upd_format_audio` BEFORE UPDATE ON `format_audio` FOR EACH ROW BEGIN

IF EXISTS (SELECT nom_format FROM format_audio WHERE nom_format = NEW.nom_format AND NEW.nom_format != OLD.nom_format)
	THEN SET @msg = "Modification impossible ce format audio existe déjà";
	signal sqlstate '45006' set message_text = @msg;
END IF;

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `format_film`
--

DROP TABLE IF EXISTS `format_film`;
CREATE TABLE IF NOT EXISTS `format_film` (
  `id_format` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom_format` varchar(40) NOT NULL,
  PRIMARY KEY (`id_format`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `format_film`
--

INSERT INTO `format_film` (`id_format`, `nom_format`) VALUES
(1, 'Blu-ray'),
(2, 'DVD');

--
-- Déclencheurs `format_film`
--
DROP TRIGGER IF EXISTS `bef_ins_format_film`;
DELIMITER $$
CREATE TRIGGER `bef_ins_format_film` BEFORE INSERT ON `format_film` FOR EACH ROW BEGIN

IF EXISTS (SELECT nom_format FROM format_film WHERE nom_format = NEW.nom_format)
	THEN SET @msg = "Ajout impossible ce format film existe déjà";
	signal sqlstate '45007' set message_text = @msg;
END IF;

END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `bef_upd_format_film`;
DELIMITER $$
CREATE TRIGGER `bef_upd_format_film` BEFORE UPDATE ON `format_film` FOR EACH ROW BEGIN

IF EXISTS (SELECT nom_format FROM format_film WHERE nom_format = NEW.nom_format AND NEW.nom_format != OLD.nom_format)
	THEN SET @msg = "Modification impossible ce format film existe déjà";
	signal sqlstate '45008' set message_text = @msg;
END IF;

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `format_livre`
--

DROP TABLE IF EXISTS `format_livre`;
CREATE TABLE IF NOT EXISTS `format_livre` (
  `id_format` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom_format` varchar(40) NOT NULL,
  PRIMARY KEY (`id_format`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `format_livre`
--

INSERT INTO `format_livre` (`id_format`, `nom_format`) VALUES
(1, 'poche'),
(2, 'digest'),
(3, 'roman'),
(4, 'A4'),
(5, 'broché');

--
-- Déclencheurs `format_livre`
--
DROP TRIGGER IF EXISTS `bef_ins_format_livre`;
DELIMITER $$
CREATE TRIGGER `bef_ins_format_livre` BEFORE INSERT ON `format_livre` FOR EACH ROW BEGIN

IF EXISTS (SELECT nom_format FROM format_livre WHERE nom_format = NEW.nom_format)
	THEN SET @msg = "Ajout impossible ce format livre existe déjà";
	signal sqlstate '45009' set message_text = @msg;
END IF;

END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `bef_upd_format_livre`;
DELIMITER $$
CREATE TRIGGER `bef_upd_format_livre` BEFORE UPDATE ON `format_livre` FOR EACH ROW BEGIN

IF EXISTS (SELECT nom_format FROM format_livre WHERE nom_format = NEW.nom_format AND NEW.nom_format != OLD.nom_format)
	THEN SET @msg = "Modification impossible ce format livre existe déjà";
	signal sqlstate '45010' set message_text = @msg;
END IF;

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `genres_audio`
--

DROP TABLE IF EXISTS `genres_audio`;
CREATE TABLE IF NOT EXISTS `genres_audio` (
  `id_genre` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom_genre` varchar(40) NOT NULL,
  PRIMARY KEY (`id_genre`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `genres_audio`
--

INSERT INTO `genres_audio` (`id_genre`, `nom_genre`) VALUES
(1, 'Variété française'),
(2, 'Pop'),
(3, 'Rock'),
(4, 'Indé');

--
-- Déclencheurs `genres_audio`
--
DROP TRIGGER IF EXISTS `bef_ins_genres_audio`;
DELIMITER $$
CREATE TRIGGER `bef_ins_genres_audio` BEFORE INSERT ON `genres_audio` FOR EACH ROW BEGIN

IF EXISTS (SELECT nom_genre FROM genres_audio WHERE nom_genre = NEW.nom_genre)
	THEN SET @msg = "Ajout impossible ce genre audio existe déjà";
	signal sqlstate '45011' set message_text = @msg;
END IF;

END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `bef_upd_genres_audio`;
DELIMITER $$
CREATE TRIGGER `bef_upd_genres_audio` BEFORE UPDATE ON `genres_audio` FOR EACH ROW BEGIN

IF EXISTS (SELECT nom_genre FROM genres_audio WHERE nom_genre = NEW.nom_genre AND NEW.nom_genre != OLD.nom_genre)
	THEN SET @msg = "Modification impossible ce genre audio existe déjà";
	signal sqlstate '45012' set message_text = @msg;
END IF;

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `genres_film`
--

DROP TABLE IF EXISTS `genres_film`;
CREATE TABLE IF NOT EXISTS `genres_film` (
  `id_genre` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom_genre` varchar(40) NOT NULL,
  PRIMARY KEY (`id_genre`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `genres_film`
--

INSERT INTO `genres_film` (`id_genre`, `nom_genre`) VALUES
(1, 'Animation'),
(2, 'Western'),
(3, 'Science-Fiction'),
(4, 'Comédie'),
(5, 'Fantastique'),
(6, 'Action');

--
-- Déclencheurs `genres_film`
--
DROP TRIGGER IF EXISTS `bef_ins_genres_film`;
DELIMITER $$
CREATE TRIGGER `bef_ins_genres_film` BEFORE INSERT ON `genres_film` FOR EACH ROW BEGIN

IF EXISTS (SELECT nom_genre FROM genres_film WHERE nom_genre = NEW.nom_genre)
	THEN SET @msg = "Ajout impossible ce genre film existe déjà";
	signal sqlstate '45013' set message_text = @msg;
END IF;

END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `bef_upd_genres_film`;
DELIMITER $$
CREATE TRIGGER `bef_upd_genres_film` BEFORE UPDATE ON `genres_film` FOR EACH ROW BEGIN

IF EXISTS (SELECT nom_genre FROM genres_film WHERE nom_genre = NEW.nom_genre AND NEW.nom_genre != OLD.nom_genre)
	THEN SET @msg = "Modification impossible ce genre film existe déjà";
	signal sqlstate '45014' set message_text = @msg;
END IF;

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `genres_livre`
--

DROP TABLE IF EXISTS `genres_livre`;
CREATE TABLE IF NOT EXISTS `genres_livre` (
  `id_genre` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom_genre` varchar(40) NOT NULL,
  PRIMARY KEY (`id_genre`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `genres_livre`
--

INSERT INTO `genres_livre` (`id_genre`, `nom_genre`) VALUES
(1, 'Romans'),
(2, 'Polar'),
(3, 'Fantasy'),
(4, 'Thriller'),
(5, 'Science Fiction'),
(6, 'Humour'),
(7, 'Fantastique');

--
-- Déclencheurs `genres_livre`
--
DROP TRIGGER IF EXISTS `bef_ins_genres_livre`;
DELIMITER $$
CREATE TRIGGER `bef_ins_genres_livre` BEFORE INSERT ON `genres_livre` FOR EACH ROW BEGIN

IF EXISTS (SELECT nom_genre FROM genres_livre WHERE nom_genre = NEW.nom_genre)
	THEN SET @msg = "Ajout impossible ce genre livre existe déjà";
	signal sqlstate '45015' set message_text = @msg;
END IF;

END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `bef_upd_genres_livre`;
DELIMITER $$
CREATE TRIGGER `bef_upd_genres_livre` BEFORE UPDATE ON `genres_livre` FOR EACH ROW BEGIN

IF EXISTS (SELECT nom_genre FROM genres_livre WHERE nom_genre = NEW.nom_genre AND NEW.nom_genre != OLD.nom_genre)
	THEN SET @msg = "Modification impossible ce genre livre existe déjà";
	signal sqlstate '45016' set message_text = @msg;
END IF;

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `historique_prix`
--

DROP TABLE IF EXISTS `historique_prix`;
CREATE TABLE IF NOT EXISTS `historique_prix` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_media` bigint(20) UNSIGNED NOT NULL,
  `prix` decimal(10,2) NOT NULL COMMENT 'doit être positif',
  `date_changement` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_media` (`id_media`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `historique_prix`
--

INSERT INTO `historique_prix` (`id`, `id_media`, `prix`, `date_changement`) VALUES
(1, 1, '20.00', '2018-05-23 11:33:15'),
(2, 2, '45.00', '2018-05-23 11:41:44'),
(3, 3, '1000.00', '2018-05-23 11:47:25'),
(4, 3, '21.00', '2018-05-23 11:55:42'),
(5, 4, '8.00', '2018-05-23 12:22:51'),
(6, 5, '500.00', '2018-05-23 18:15:17'),
(7, 5, '1500.00', '2018-05-25 09:43:43'),
(8, 6, '10.00', '2018-05-29 12:43:59'),
(9, 7, '21.00', '2018-05-29 12:55:40'),
(10, 8, '15.00', '2018-05-29 13:08:18'),
(11, 2, '55.00', '2018-05-29 14:40:08'),
(12, 9, '30.00', '2018-05-29 15:19:18'),
(13, 10, '50.00', '2018-05-29 15:28:28'),
(14, 11, '10.00', '2018-05-29 15:33:54'),
(15, 12, '20.00', '2018-05-29 15:38:08');

-- --------------------------------------------------------

--
-- Structure de la table `media`
--

DROP TABLE IF EXISTS `media`;
CREATE TABLE IF NOT EXISTS `media` (
  `id_media` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `titre` varchar(90) NOT NULL,
  `prix` decimal(10,2) NOT NULL,
  `etat` enum('a','w','b') NOT NULL COMMENT 'a = acceptable, b = bloqué, w= en attente',
  `annee` smallint(5) UNSIGNED NOT NULL,
  `stock` int(10) NOT NULL,
  `id_support` int(10) UNSIGNED NOT NULL,
  `type` enum('musique','film','livre') NOT NULL,
  PRIMARY KEY (`id_media`),
  KEY `id_support` (`id_support`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `media`
--

INSERT INTO `media` (`id_media`, `titre`, `prix`, `etat`, `annee`, `stock`, `id_support`, `type`) VALUES
(1, 'La Jeune Fille et la nuit', '20.00', 'a', 2018, 49, 1, 'livre'),
(2, 'Le Seigneur des anneaux', '55.00', 'a', 1992, 95, 1, 'livre'),
(3, 'La Terre des morts', '21.00', 'a', 2018, 49, 2, 'livre'),
(4, 'Ça - tome 1', '8.00', 'a', 2002, 0, 1, 'livre'),
(5, 'testphp', '1500.00', 'b', 1232, 555, 1, 'livre'),
(6, 'Beyond my control', '10.00', 'a', 2018, 28, 1, 'musique'),
(7, 'Entre gris clair et gris foncé', '21.00', 'a', 2016, 15, 1, 'musique'),
(8, 'Bad', '15.00', 'a', 2016, 48, 2, 'musique'),
(9, 'Deadpool 2', '30.00', 'w', 2018, 200, 1, 'film'),
(10, 'Solo : A Star Wars Story', '50.00', 'a', 2018, 49, 1, 'film'),
(11, 'Vaiana, la légende du bout du monde', '10.00', 'a', 2017, 29, 1, 'film'),
(12, 'Le Spécialiste', '20.00', 'a', 2006, 50, 1, 'film');

--
-- Déclencheurs `media`
--
DROP TRIGGER IF EXISTS `after_ins_media`;
DELIMITER $$
CREATE TRIGGER `after_ins_media` AFTER INSERT ON `media` FOR EACH ROW INSERT INTO historique_prix(id_media, prix) VALUES (NEW.id_media, NEW.prix)
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `bef_upd_media`;
DELIMITER $$
CREATE TRIGGER `bef_upd_media` BEFORE UPDATE ON `media` FOR EACH ROW IF NEW.prix != OLD.prix THEN
	INSERT INTO historique_prix(id_media, prix) VALUES (OLD.id_media, NEW.prix);
END IF
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `media_audio`
--

DROP TABLE IF EXISTS `media_audio`;
CREATE TABLE IF NOT EXISTS `media_audio` (
  `id_media` bigint(20) UNSIGNED NOT NULL,
  `duree` int(11) UNSIGNED NOT NULL COMMENT 'nombre de minutes',
  `id_compositeur` int(10) UNSIGNED NOT NULL,
  `id_format_audio` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id_media`),
  KEY `id_compositeur` (`id_compositeur`),
  KEY `id_format_audio` (`id_format_audio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `media_audio`
--

INSERT INTO `media_audio` (`id_media`, `duree`, `id_compositeur`, `id_format_audio`) VALUES
(6, 8, 6, 1),
(7, 80, 7, 2),
(8, 70, 8, 1);

-- --------------------------------------------------------

--
-- Structure de la table `media_audio_genres`
--

DROP TABLE IF EXISTS `media_audio_genres`;
CREATE TABLE IF NOT EXISTS `media_audio_genres` (
  `id_media_audio` bigint(20) UNSIGNED NOT NULL,
  `id_genre_audio` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id_media_audio`,`id_genre_audio`),
  KEY `id_genre_audio` (`id_genre_audio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='genres associés par audio';

--
-- Déchargement des données de la table `media_audio_genres`
--

INSERT INTO `media_audio_genres` (`id_media_audio`, `id_genre_audio`) VALUES
(6, 1),
(7, 1),
(7, 2),
(8, 2),
(7, 3),
(8, 3),
(8, 4);

-- --------------------------------------------------------

--
-- Structure de la table `media_film`
--

DROP TABLE IF EXISTS `media_film`;
CREATE TABLE IF NOT EXISTS `media_film` (
  `id_media` bigint(20) UNSIGNED NOT NULL,
  `duree` int(10) UNSIGNED NOT NULL COMMENT 'nombre de minute',
  `id_format_film` int(10) UNSIGNED NOT NULL,
  `id_realisateur` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id_media`),
  KEY `id_format` (`id_format_film`),
  KEY `id_realisateur` (`id_realisateur`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `media_film`
--

INSERT INTO `media_film` (`id_media`, `duree`, `id_format_film`, `id_realisateur`) VALUES
(9, 120, 1, 9),
(10, 135, 1, 15),
(11, 107, 1, 20),
(12, 104, 2, 23);

-- --------------------------------------------------------

--
-- Structure de la table `media_film_genres`
--

DROP TABLE IF EXISTS `media_film_genres`;
CREATE TABLE IF NOT EXISTS `media_film_genres` (
  `id_media_film` bigint(20) UNSIGNED NOT NULL,
  `id_genre_film` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id_media_film`,`id_genre_film`),
  KEY `id_genre_film` (`id_genre_film`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='genres associés par film';

--
-- Déchargement des données de la table `media_film_genres`
--

INSERT INTO `media_film_genres` (`id_media_film`, `id_genre_film`) VALUES
(11, 1),
(12, 2),
(10, 3),
(9, 5),
(9, 6),
(10, 6);

-- --------------------------------------------------------

--
-- Structure de la table `media_livre`
--

DROP TABLE IF EXISTS `media_livre`;
CREATE TABLE IF NOT EXISTS `media_livre` (
  `id_media` bigint(20) UNSIGNED NOT NULL,
  `ISBN` varchar(60) NOT NULL,
  `id_editeur` int(11) UNSIGNED NOT NULL,
  `id_format_livre` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id_media`),
  KEY `id_editeur` (`id_editeur`),
  KEY `id_format_livre` (`id_format_livre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `media_livre`
--

INSERT INTO `media_livre` (`id_media`, `ISBN`, `id_editeur`, `id_format_livre`) VALUES
(1, '2702163637', 1, 5),
(2, '2267011255', 5, 1),
(3, '2226392092', 6, 5),
(4, '2253151343', 7, 1),
(5, 'moimoi', 5, 2);

--
-- Déclencheurs `media_livre`
--
DROP TRIGGER IF EXISTS `media_livre_after_delete`;
DELIMITER $$
CREATE TRIGGER `media_livre_after_delete` AFTER DELETE ON `media_livre` FOR EACH ROW BEGIN

DELETE FROM media WHERE id_media = OLD.id_media;

END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `media_livre_before_delete`;
DELIMITER $$
CREATE TRIGGER `media_livre_before_delete` BEFORE DELETE ON `media_livre` FOR EACH ROW BEGIN

DELETE FROM media_livre_genres WHERE id_media_livre = OLD.id_media;

DELETE FROM p_auteurs WHERE id_media_livre = OLD.id_media;

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `media_livre_genres`
--

DROP TABLE IF EXISTS `media_livre_genres`;
CREATE TABLE IF NOT EXISTS `media_livre_genres` (
  `id_media_livre` bigint(20) UNSIGNED NOT NULL,
  `id_genre_livre` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id_media_livre`,`id_genre_livre`),
  KEY `id_genre_livre` (`id_genre_livre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='genres associés par livre';

--
-- Déchargement des données de la table `media_livre_genres`
--

INSERT INTO `media_livre_genres` (`id_media_livre`, `id_genre_livre`) VALUES
(1, 1),
(3, 1),
(2, 3),
(3, 4),
(5, 6),
(4, 7),
(5, 7);

-- --------------------------------------------------------

--
-- Structure de la table `personnes`
--

DROP TABLE IF EXISTS `personnes`;
CREATE TABLE IF NOT EXISTS `personnes` (
  `id_personne` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `full_name` varchar(60) NOT NULL,
  PRIMARY KEY (`id_personne`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `personnes`
--

INSERT INTO `personnes` (`id_personne`, `full_name`) VALUES
(1, 'Guillaume Musso'),
(2, 'John Ronald Reuel Tolkien'),
(3, 'Jean-Christophe Grange'),
(4, 'Stephen King'),
(5, 'Mylène Farmer'),
(6, 'Laurent Boutonnat'),
(7, 'Jean-Jacques Goldman'),
(8, 'Michael Jackson'),
(9, 'David Leitch'),
(10, 'Ryan Reynolds'),
(11, 'Josh Brolin'),
(12, 'Morena Baccarin'),
(13, 'Julian Dennison'),
(14, 'Zazie Beetz'),
(15, 'Ron Howard'),
(16, 'Alden Eherenreich'),
(17, 'Woody Harrelson'),
(18, 'Emilia Clarke'),
(19, 'Donald Glover'),
(20, 'John Musker'),
(21, 'Cerise Calixe'),
(22, 'Anthony Kavanagh'),
(23, 'Sergio Corbucci'),
(24, 'Johnny Hallyday'),
(25, 'Gastone Moschin');

--
-- Déclencheurs `personnes`
--
DROP TRIGGER IF EXISTS `bef_ins_personnnes`;
DELIMITER $$
CREATE TRIGGER `bef_ins_personnnes` BEFORE INSERT ON `personnes` FOR EACH ROW BEGIN

IF EXISTS (SELECT full_name FROM personnes WHERE full_name = NEW.full_name)
	THEN SET @msg = "Ajout impossible ce nom existe déjà";
	signal sqlstate '45017' set message_text = @msg;
END IF;

END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `bef_upd_personnes`;
DELIMITER $$
CREATE TRIGGER `bef_upd_personnes` BEFORE UPDATE ON `personnes` FOR EACH ROW BEGIN

IF EXISTS (SELECT full_name FROM personnes WHERE full_name = NEW.full_name
          AND NEW.full_name != OLD.full_name)
	THEN SET @msg = "Modification impossible ce nom existe déjà";
	signal sqlstate '45018' set message_text = @msg;
END IF;

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `p_acteurs`
--

DROP TABLE IF EXISTS `p_acteurs`;
CREATE TABLE IF NOT EXISTS `p_acteurs` (
  `id_acteur` int(10) UNSIGNED NOT NULL,
  `id_media_film` bigint(20) UNSIGNED NOT NULL,
  PRIMARY KEY (`id_acteur`,`id_media_film`),
  KEY `id_media_film` (`id_media_film`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `p_acteurs`
--

INSERT INTO `p_acteurs` (`id_acteur`, `id_media_film`) VALUES
(10, 9),
(11, 9),
(12, 9),
(13, 9),
(14, 9),
(16, 10),
(17, 10),
(18, 10),
(19, 10),
(21, 11),
(22, 11),
(24, 12),
(25, 12);

-- --------------------------------------------------------

--
-- Structure de la table `p_auteurs`
--

DROP TABLE IF EXISTS `p_auteurs`;
CREATE TABLE IF NOT EXISTS `p_auteurs` (
  `id_auteur` int(10) UNSIGNED NOT NULL,
  `id_media_livre` bigint(20) UNSIGNED NOT NULL,
  PRIMARY KEY (`id_auteur`,`id_media_livre`),
  KEY `id_media_livre` (`id_media_livre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `p_auteurs`
--

INSERT INTO `p_auteurs` (`id_auteur`, `id_media_livre`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(3, 5);

-- --------------------------------------------------------

--
-- Structure de la table `p_interpretes`
--

DROP TABLE IF EXISTS `p_interpretes`;
CREATE TABLE IF NOT EXISTS `p_interpretes` (
  `id_interprete` int(10) UNSIGNED NOT NULL,
  `id_media_audio` bigint(20) UNSIGNED NOT NULL,
  PRIMARY KEY (`id_media_audio`,`id_interprete`),
  KEY `id_personne` (`id_interprete`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `p_interpretes`
--

INSERT INTO `p_interpretes` (`id_interprete`, `id_media_audio`) VALUES
(5, 6),
(7, 7),
(8, 8);

-- --------------------------------------------------------

--
-- Structure de la table `supports`
--

DROP TABLE IF EXISTS `supports`;
CREATE TABLE IF NOT EXISTS `supports` (
  `id_support` int(10) UNSIGNED NOT NULL,
  `type_support` varchar(20) NOT NULL,
  PRIMARY KEY (`id_support`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `supports`
--

INSERT INTO `supports` (`id_support`, `type_support`) VALUES
(1, 'physique'),
(2, 'numérique');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `login` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `droit` enum('u','a','s') NOT NULL DEFAULT 'u' COMMENT 'u = utilisateur, a = admin, s = super admin',
  `actif` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `email`, `droit`, `actif`) VALUES
(0, 'john_doe', '$2a$10$9B5xjvYHLexObOGo6FQmMOUPDApgMoEukJeubz/cI0Z2lLiB/vCCG', 'john_doe@john_doe', 'u', 1),
(1, 'bob', '$2a$10$ykb128K3UJDlEuIIxP2Huu.q70Q7fnZiRdlV3U.r6wqOiIsK9DAv6', 'bob@btssio.win', 's', 1),
(2, 'admin1', '$2a$10$ob84399eza4RANI6upH.DeSvXxPsIijlgAJQggoYB9SR.VMeB6uya', 'admin1@test.net', 'a', 1),
(3, 'client1', '$2y$10$em.Urm6wa4BOAz1o8LHJZ.LI1688MYrjXtE/J20.hEO5oZIwXoBoe', 'client1@test.com', 'u', 1),
(4, 'admin2', '$2a$10$stPHdBPpDCx9ovCM9DNz4ebsz4oyR2nd8qOg9xBMWrqmgB/RuLzCK', 'admin2@test.com', 'a', 1),
(5, 'client2', '$2a$10$ED.mPSvSKgqyzqdWCj9Hfema6Lv7No7CI8H1LjCVhodE.C.W4mlZm', 'client2@test.jp', 'u', 1),
(6, 'client3', '$2a$10$y6MaGfkHEOdxL4Uc7Ha4tOIA14m9V9R9nQklWUdPA5c5tN6264PyG', 'blabla@email', 'u', 1),
(7, 'test', '$2y$10$ZdrBv.cCpy2umfywitfmfuLWiSdE4PPnsFbUbbez6xf69a4wjYj.6', 'test@test.com', 'u', 1),
(8, 'hattem', '$2y$10$G12fSqacImrjjEAUaJ5q5uOh2wAZFSCLuW0JBhnhJWknOiTHSXS2a', 'hattem@blabla.com', 'u', 1);

--
-- Déclencheurs `users`
--
DROP TRIGGER IF EXISTS `before_ins_users`;
DELIMITER $$
CREATE TRIGGER `before_ins_users` BEFORE INSERT ON `users` FOR EACH ROW BEGIN

IF EXISTS (SELECT login FROM users WHERE login = NEW.login)
	THEN SET @msg = "Ajout impossible ce nom d'utilsateur existe déjà";
	signal sqlstate '45000' set message_text = @msg;
END IF;

IF EXISTS (SELECT email FROM users WHERE email = NEW.email)
	THEN SET @msg = 'Ajout impossible cette email est déjà utilisé';
	signal sqlstate '45001' set message_text = @msg;
END IF;

END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `before_update_users`;
DELIMITER $$
CREATE TRIGGER `before_update_users` BEFORE UPDATE ON `users` FOR EACH ROW BEGIN

IF EXISTS (SELECT login FROM users WHERE login = NEW.login AND NEW.login != OLD.login )
	THEN SET @msg = "Modification impossible ce nom d'utilsateur existe déjà";
	signal sqlstate '45000' set message_text = @msg;
END IF;

IF EXISTS (SELECT email FROM users WHERE email = NEW.email AND NEW.email != OLD.email)
	THEN SET @msg = 'Modification impossible cette email est déjà utilisé';
	signal sqlstate '45001' set message_text = @msg;
END IF;

END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `update_commande_before_delete`;
DELIMITER $$
CREATE TRIGGER `update_commande_before_delete` BEFORE DELETE ON `users` FOR EACH ROW UPDATE commande SET id_user = 0 WHERE id_user = OLD.id
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `v_film_fiche`
-- (Voir ci-dessous la vue réelle)
--
DROP VIEW IF EXISTS `v_film_fiche`;
CREATE TABLE IF NOT EXISTS `v_film_fiche` (
`id_media` bigint(20) unsigned
,`titre` varchar(90)
,`prix` decimal(10,2)
,`etat` enum('a','w','b')
,`annee` smallint(5) unsigned
,`stock` int(10)
,`duree` int(10) unsigned
,`id_support` int(10) unsigned
,`realisateur` varchar(60)
,`nom_format` varchar(40)
,`type_support` varchar(20)
);

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `v_info_commande`
-- (Voir ci-dessous la vue réelle)
--
DROP VIEW IF EXISTS `v_info_commande`;
CREATE TABLE IF NOT EXISTS `v_info_commande` (
`id_commande` bigint(20) unsigned
,`date_commande` timestamp
,`login` varchar(60)
,`id_user` int(10) unsigned
,`total` decimal(42,2)
);

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `v_livre_fiche`
-- (Voir ci-dessous la vue réelle)
--
DROP VIEW IF EXISTS `v_livre_fiche`;
CREATE TABLE IF NOT EXISTS `v_livre_fiche` (
`id_media` bigint(20) unsigned
,`titre` varchar(90)
,`prix` decimal(10,2)
,`etat` enum('a','w','b')
,`annee` smallint(5) unsigned
,`stock` int(10)
,`ISBN` varchar(60)
,`id_support` int(10) unsigned
,`nom_editeur` varchar(60)
,`nom_format` varchar(40)
,`type_support` varchar(20)
);

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `v_musique_fiche`
-- (Voir ci-dessous la vue réelle)
--
DROP VIEW IF EXISTS `v_musique_fiche`;
CREATE TABLE IF NOT EXISTS `v_musique_fiche` (
`id_media` bigint(20) unsigned
,`titre` varchar(90)
,`prix` decimal(10,2)
,`etat` enum('a','w','b')
,`annee` smallint(5) unsigned
,`stock` int(10)
,`duree` int(11) unsigned
,`id_support` int(10) unsigned
,`compositeur` varchar(60)
,`nom_format` varchar(40)
,`type_support` varchar(20)
);

-- --------------------------------------------------------

--
-- Structure de la vue `v_film_fiche`
--
DROP TABLE IF EXISTS `v_film_fiche`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_film_fiche`  AS  select `media`.`id_media` AS `id_media`,`media`.`titre` AS `titre`,`media`.`prix` AS `prix`,`media`.`etat` AS `etat`,`media`.`annee` AS `annee`,`media`.`stock` AS `stock`,`media_film`.`duree` AS `duree`,`media`.`id_support` AS `id_support`,`personnes`.`full_name` AS `realisateur`,`format_film`.`nom_format` AS `nom_format`,`supports`.`type_support` AS `type_support` from ((((`media` join `media_film` on((`media`.`id_media` = `media_film`.`id_media`))) join `personnes` on((`personnes`.`id_personne` = `media_film`.`id_realisateur`))) join `format_film` on((`format_film`.`id_format` = `media_film`.`id_format_film`))) join `supports` on((`supports`.`id_support` = `media`.`id_support`))) ;

-- --------------------------------------------------------

--
-- Structure de la vue `v_info_commande`
--
DROP TABLE IF EXISTS `v_info_commande`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_info_commande`  AS  select `commande`.`id_commande` AS `id_commande`,`commande`.`date_commande` AS `date_commande`,`users`.`login` AS `login`,`users`.`id` AS `id_user`,sum((`commande_ligne`.`qtx` * `h`.`prix`)) AS `total` from (((`users` join `commande` on((`users`.`id` = `commande`.`id_user`))) join `commande_ligne` on((`commande`.`id_commande` = `commande_ligne`.`id_commande`))) join `historique_prix` `h` on((`commande_ligne`.`id_media` = `h`.`id_media`))) where ((`h`.`date_changement` < `commande`.`date_commande`) and ((select count(0) from `historique_prix` `h2` where ((`h`.`id_media` = `h2`.`id_media`) and (`h2`.`date_changement` < `commande`.`date_commande`) and (`h2`.`date_changement` > `h`.`date_changement`))) < 1)) group by `commande`.`id_commande` ;

-- --------------------------------------------------------

--
-- Structure de la vue `v_livre_fiche`
--
DROP TABLE IF EXISTS `v_livre_fiche`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_livre_fiche`  AS  select `media`.`id_media` AS `id_media`,`media`.`titre` AS `titre`,`media`.`prix` AS `prix`,`media`.`etat` AS `etat`,`media`.`annee` AS `annee`,`media`.`stock` AS `stock`,`media_livre`.`ISBN` AS `ISBN`,`media`.`id_support` AS `id_support`,`edition`.`nom_editeur` AS `nom_editeur`,`format_livre`.`nom_format` AS `nom_format`,`supports`.`type_support` AS `type_support` from ((((`media` join `media_livre` on((`media`.`id_media` = `media_livre`.`id_media`))) join `edition` on((`edition`.`id_editeur` = `media_livre`.`id_editeur`))) join `format_livre` on((`format_livre`.`id_format` = `media_livre`.`id_format_livre`))) join `supports` on((`supports`.`id_support` = `media`.`id_support`))) ;

-- --------------------------------------------------------

--
-- Structure de la vue `v_musique_fiche`
--
DROP TABLE IF EXISTS `v_musique_fiche`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_musique_fiche`  AS  select `media`.`id_media` AS `id_media`,`media`.`titre` AS `titre`,`media`.`prix` AS `prix`,`media`.`etat` AS `etat`,`media`.`annee` AS `annee`,`media`.`stock` AS `stock`,`media_audio`.`duree` AS `duree`,`media`.`id_support` AS `id_support`,`personnes`.`full_name` AS `compositeur`,`format_audio`.`nom_format` AS `nom_format`,`supports`.`type_support` AS `type_support` from ((((`media` join `media_audio` on((`media`.`id_media` = `media_audio`.`id_media`))) join `personnes` on((`personnes`.`id_personne` = `media_audio`.`id_compositeur`))) join `format_audio` on((`format_audio`.`id_format` = `media_audio`.`id_format_audio`))) join `supports` on((`supports`.`id_support` = `media`.`id_support`))) ;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `commande`
--
ALTER TABLE `commande`
  ADD CONSTRAINT `commande_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`);

--
-- Contraintes pour la table `commande_ligne`
--
ALTER TABLE `commande_ligne`
  ADD CONSTRAINT `commande_ligne_ibfk_1` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`),
  ADD CONSTRAINT `commande_ligne_ibfk_2` FOREIGN KEY (`id_media`) REFERENCES `media` (`id_media`);

--
-- Contraintes pour la table `historique_prix`
--
ALTER TABLE `historique_prix`
  ADD CONSTRAINT `historique_prix_ibfk_1` FOREIGN KEY (`id_media`) REFERENCES `media` (`id_media`);

--
-- Contraintes pour la table `media`
--
ALTER TABLE `media`
  ADD CONSTRAINT `media_ibfk_1` FOREIGN KEY (`id_support`) REFERENCES `supports` (`id_support`);

--
-- Contraintes pour la table `media_audio`
--
ALTER TABLE `media_audio`
  ADD CONSTRAINT `media_audio_ibfk_1` FOREIGN KEY (`id_format_audio`) REFERENCES `format_audio` (`id_format`),
  ADD CONSTRAINT `media_audio_ibfk_2` FOREIGN KEY (`id_compositeur`) REFERENCES `personnes` (`id_personne`),
  ADD CONSTRAINT `media_audio_ibfk_3` FOREIGN KEY (`id_media`) REFERENCES `media` (`id_media`);

--
-- Contraintes pour la table `media_audio_genres`
--
ALTER TABLE `media_audio_genres`
  ADD CONSTRAINT `media_audio_genres_ibfk_1` FOREIGN KEY (`id_media_audio`) REFERENCES `media_audio` (`id_media`),
  ADD CONSTRAINT `media_audio_genres_ibfk_2` FOREIGN KEY (`id_genre_audio`) REFERENCES `genres_audio` (`id_genre`);

--
-- Contraintes pour la table `media_film`
--
ALTER TABLE `media_film`
  ADD CONSTRAINT `media_film_ibfk_1` FOREIGN KEY (`id_format_film`) REFERENCES `format_film` (`id_format`),
  ADD CONSTRAINT `media_film_ibfk_2` FOREIGN KEY (`id_media`) REFERENCES `media` (`id_media`),
  ADD CONSTRAINT `media_film_ibfk_3` FOREIGN KEY (`id_realisateur`) REFERENCES `personnes` (`id_personne`);

--
-- Contraintes pour la table `media_film_genres`
--
ALTER TABLE `media_film_genres`
  ADD CONSTRAINT `media_film_genres_ibfk_1` FOREIGN KEY (`id_media_film`) REFERENCES `media_film` (`id_media`),
  ADD CONSTRAINT `media_film_genres_ibfk_2` FOREIGN KEY (`id_genre_film`) REFERENCES `genres_film` (`id_genre`);

--
-- Contraintes pour la table `media_livre`
--
ALTER TABLE `media_livre`
  ADD CONSTRAINT `media_livre_ibfk_1` FOREIGN KEY (`id_editeur`) REFERENCES `edition` (`id_editeur`),
  ADD CONSTRAINT `media_livre_ibfk_2` FOREIGN KEY (`id_format_livre`) REFERENCES `format_livre` (`id_format`),
  ADD CONSTRAINT `media_livre_ibfk_3` FOREIGN KEY (`id_media`) REFERENCES `media` (`id_media`);

--
-- Contraintes pour la table `media_livre_genres`
--
ALTER TABLE `media_livre_genres`
  ADD CONSTRAINT `media_livre_genres_ibfk_1` FOREIGN KEY (`id_media_livre`) REFERENCES `media_livre` (`id_media`),
  ADD CONSTRAINT `media_livre_genres_ibfk_2` FOREIGN KEY (`id_genre_livre`) REFERENCES `genres_livre` (`id_genre`);

--
-- Contraintes pour la table `p_acteurs`
--
ALTER TABLE `p_acteurs`
  ADD CONSTRAINT `p_acteurs_ibfk_1` FOREIGN KEY (`id_acteur`) REFERENCES `personnes` (`id_personne`),
  ADD CONSTRAINT `p_acteurs_ibfk_2` FOREIGN KEY (`id_media_film`) REFERENCES `media_film` (`id_media`);

--
-- Contraintes pour la table `p_auteurs`
--
ALTER TABLE `p_auteurs`
  ADD CONSTRAINT `p_auteurs_ibfk_1` FOREIGN KEY (`id_auteur`) REFERENCES `personnes` (`id_personne`),
  ADD CONSTRAINT `p_auteurs_ibfk_2` FOREIGN KEY (`id_media_livre`) REFERENCES `media_livre` (`id_media`);

--
-- Contraintes pour la table `p_interpretes`
--
ALTER TABLE `p_interpretes`
  ADD CONSTRAINT `p_interpretes_ibfk_1` FOREIGN KEY (`id_media_audio`) REFERENCES `media_audio` (`id_media`),
  ADD CONSTRAINT `p_interpretes_ibfk_2` FOREIGN KEY (`id_interprete`) REFERENCES `personnes` (`id_personne`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
