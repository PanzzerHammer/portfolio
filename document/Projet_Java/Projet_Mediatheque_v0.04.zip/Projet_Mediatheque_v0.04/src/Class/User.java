/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Class;

import Util.BCrypt;
import Util.MySqlConnect;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Panzzer
 */
public class User {

    private int id;
    private String pseudo;
    private String email;
    private String droit;
    private PreparedStatement pst;
    private ResultSet rs;
    private ArrayList<User> listUser = new ArrayList<>();

    public User(int id, String pseudo, String email, String droit) {
        this.id = id;
        this.pseudo = pseudo;
        this.email = email;
        this.droit = droit;
    }

    public User() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPseudo() {
        return pseudo;
    }

    public void setPseudo(String pseudo) {
        this.pseudo = pseudo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDroit() {
        return droit;
    }

    public void setDroit(String droit) {
        this.droit = droit;
    }

    public ArrayList<User> getListUser() {
        return listUser;
    }

    public void setListUser(ArrayList<User> listUser) {
        this.listUser = listUser;
    }

    public boolean verifCompte(String pseudo, String mdp) {
        boolean testCompte = false;
        MySqlConnect.testConn();
        if (MySqlConnect.conn != null) {
            try {
                String request = "SELECT * FROM users WHERE login = ?";
                pst = MySqlConnect.conn.prepareStatement(request);
                pst.setString(1, pseudo);
                rs = pst.executeQuery();
                if (rs.next()) {
                    if ("a".equals(rs.getString("droit")) || "s".equals(rs.getString("droit"))) {
                        if (BCrypt.checkpw(mdp, rs.getString("password"))) {
                            this.id = rs.getInt("id");
                            this.pseudo = rs.getString("login");
                            this.email = rs.getString("email");
                            this.droit = rs.getString("droit");
                            testCompte = true;
                        } else {
                            JOptionPane.showMessageDialog(null, "Login ou Mot de pass incorect");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Les clients ne sont pas autorisés à  utiliser ce ");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Login ou Mot de pass incorect");
                }
                pst.close();

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "problème avec verifCompte()" + ex.getMessage(), "Problème rencontré",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
        return testCompte;
    }

    public void recupUserDB() {
        String request;
        if ("s".equals(this.droit)) {
            request = "SELECT * FROM users WHERE droit = 'a' OR droit = 'u'";
        } else {
            request = "SELECT * FROM users WHERE droit = 'u'";
        }
        MySqlConnect.testConn();
        if (MySqlConnect.conn != null) {
            try {
                pst = MySqlConnect.conn.prepareStatement(request);
                rs = pst.executeQuery();
                this.listUser = new ArrayList<>();
                while (rs.next()) {
                    int idR = rs.getInt("id");
                    String pseudoR = rs.getString("login");
                    String emailR = rs.getString("email");
                    String droitR = rs.getString("droit");
                    this.listUser.add(new User(idR, pseudoR, emailR, droitR));
                }
                pst.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "problème avec recupUserDB()" + ex.getMessage(), "Problème rencontré",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public boolean modifUser(String pseudo, String email, String droit, String mdp, int idUser) {
        boolean testModif = false;
        MySqlConnect.testConn();
        if (MySqlConnect.conn != null) {
            try {
                String request = "UPDATE users SET login=?, email=?, droit=?";
                if (!"".equals(mdp)) {
                    request += ",password=? ";
                }
                request += "WHERE id =?";

                pst = MySqlConnect.conn.prepareStatement(request);
                pst.setString(1, pseudo);
                pst.setString(2, email);
                pst.setString(3, droit);
                if (!"".equals(mdp)) {
                    pst.setString(4, mdp);
                    pst.setInt(5, idUser);
                } else {
                    pst.setInt(4, idUser);
                }
                pst.executeUpdate();
                testModif = true;
                pst.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "problème avec modifUser()" + ex.getMessage(), "Problème rencontré",
                        JOptionPane.ERROR_MESSAGE);
            }
        }

        return testModif;
    }

    public boolean addUser(String pseudo, String email, String droit, String mdp) {
        boolean testAjou = false;
        MySqlConnect.testConn();
        if (MySqlConnect.conn != null) {
            try {
                String request = "INSERT INTO users (id, login, password, email, droit) VALUES (NULL, ?, ?, ?, ?)";
                pst = MySqlConnect.conn.prepareStatement(request);
                pst.setString(1, pseudo);
                pst.setString(2, mdp);
                pst.setString(3, email);
                pst.setString(4, droit);
                pst.executeUpdate();
                testAjou = true;
                pst.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "problème avec addUser()" + ex.getMessage(), "Problème rencontré",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
        return testAjou;
    }

    public boolean suppUser(int idUser) {
        boolean testSupp = false;
        MySqlConnect.testConn();
        if (MySqlConnect.conn != null) {
            try {
                String request = "DELETE FROM users WHERE id = ?";
                pst = MySqlConnect.conn.prepareStatement(request);
                pst.setInt(1, idUser);
                pst.executeUpdate();
                testSupp = true;
                pst.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "problème avec suppUser()" + ex.getMessage(), "Problème rencontré",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
        return testSupp;
    }
}
