/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Class.Media;

/**
 *
 * @author Panzzer
 */
public class C_Media {
    
    private final Media intanceMedia = new Media();
    
    public C_Media(){
    }

    public Media getIntanceMedia() {
        return intanceMedia;
    }
    
    public void getListMedia(String typeArticle, boolean physique, boolean numerique, boolean acceptable, boolean bloque, boolean enAttente, int stock){
        String option = "";
        String accep = "";
        String bloq = "";
        String enAtt = "";
        
        if (physique && !numerique){
            option = " AND media.id_support = 1";
        }
        if (!physique && numerique){
            option = " AND media.id_support = 2";
        }
        
        if(acceptable){
            accep = "a";
        }
        if(bloque){
            bloq = "b";
        }
        if(enAttente){
            enAtt = "w";
        }
        
        String etatRequete = " (media.etat = '"+ accep +"' OR media.etat = '"+ bloq +"' OR media.etat = '"+ enAtt +"') ";
        
        if (stock == 0){
            option += " AND media.stock = 0";
        }
        if (stock >0){
            option += " AND media.stock <" + stock;
        }
        
        this.intanceMedia.recupMediaDB(typeArticle, etatRequete, option);
    }
    
    public boolean modMedia (int id, String titre, double prix, String etat, int annee, int stock, int idSupport){
        return this.intanceMedia.modMediaDB(id, titre, prix, etat, annee, stock, idSupport);
    }
    
}
