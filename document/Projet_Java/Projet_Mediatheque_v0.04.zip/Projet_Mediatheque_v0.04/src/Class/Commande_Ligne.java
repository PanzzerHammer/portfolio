/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Class;

import Util.MySqlConnect;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Panzzer
 */
public class Commande_Ligne {

    private String titre;
    private String type;
    private double prix;
    private int quantite;
    private PreparedStatement pst;
    private ResultSet rs;
    private ArrayList<Commande_Ligne> listCommandeLigne;

    public Commande_Ligne(String titre, String type, double prix, int quantite) {
        this.titre = titre;
        this.type = type;
        this.prix = prix;
        this.quantite = quantite;
    }

    public Commande_Ligne() {
    }

    public String getTitre() {
        return titre;
    }

    public String getType() {
        return type;
    }

    public double getPrix() {
        return prix;
    }

    public int getQuantite() {
        return quantite;
    }

    public ArrayList<Commande_Ligne> getListCommandeLigne() {
        return listCommandeLigne;
    }

    public void recupCommandeLigneDB(int id) {
        String request = "SELECT media.titre, media.type, h.prix, commande_ligne.qtx FROM commande"
                + " JOIN commande_ligne ON commande.id_commande = commande_ligne.id_commande"
                + " JOIN media ON commande_ligne.id_media = media.id_media"
                + " JOIN historique_prix h ON media.id_media = h.id_media"
                + " WHERE h.date_changement < commande.date_commande"
                + " AND (SELECT COUNT(*) FROM historique_prix h2 WHERE h.id_media = h2.id_media AND h2.date_changement < commande.date_commande AND h2.date_changement > h.date_changement) < 1"
                + " AND commande.id_commande = ?";
        MySqlConnect.testConn();
        if (MySqlConnect.conn != null) {
            try {
                pst = MySqlConnect.conn.prepareStatement(request);
                pst.setInt(1, id);
                rs = pst.executeQuery();
                this.listCommandeLigne = new ArrayList<>();
                while (rs.next()) {
                    String titreR = rs.getString("titre");
                    String typeR = rs.getString("type");
                    double prixR = rs.getDouble("prix");
                    int quantiteR = rs.getInt("qtx");
                    this.listCommandeLigne.add(new Commande_Ligne(titreR, typeR, prixR, quantiteR));
                }
                pst.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "problème avec recupCommandeLigneDB()" + ex.getMessage(), "Problème rencontré",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
