/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Class.Commande_Ligne;
import java.util.ArrayList;

/**
 *
 * @author Panzzer
 */
public class C_Commande_Ligne {

    private Commande_Ligne intanceCommandeLigne = new Commande_Ligne();

    public C_Commande_Ligne() {
    }

    public ArrayList<Commande_Ligne> recupCommande(int id) {
        this.intanceCommandeLigne.recupCommandeLigneDB(id);
        return this.intanceCommandeLigne.getListCommandeLigne();
    }
}
