<!-- Banner -->
<div id="banner-wrapper">
    <div id="banner" class="box container">
        <div class="row">
            <div class="7u 12u(medium)">
                <p>Vous devez vous connecter à votre compte pour pouvoir passer commande</p>
            </div>
            <div class="5u 12u(medium)">
                <ul>
                    <li><a href="index.php?uc=gesCompt&ac=signin&old=accueil" class="button big icon fa-user-plus">Sign-in</a></li>
                    <li><a href="index.php?uc=gesCompt&ac=login&old=accueil" class="button alt big icon fa-sign-in">Log-in</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>