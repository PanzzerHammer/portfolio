/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Class.Autre;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Panzzer
 */
public class C_Autre {

    private Autre intanceAutre = new Autre();

    public C_Autre() {
    }

    public Autre getIntanceAutre() {
        return intanceAutre;
    }

    private String[] infoBDD(int index) {
        String[] resultat = null;
        switch (index) {
            case 0:
                resultat = new String[]{"edition", "id_editeur", "nom_editeur"};
                break;
            case 1:
                resultat = new String[]{"format_audio", "id_format", "nom_format"};
                break;
            case 2:
                resultat = new String[]{"format_film", "id_format", "nom_format"};
                break;
            case 3:
                resultat = new String[]{"format_livre", "id_format", "nom_format"};
                break;
            case 4:
                resultat = new String[]{"genres_audio", "id_genre", "nom_genre"};
                break;
            case 5:
                resultat = new String[]{"genres_film", "id_genre", "nom_genre"};
                break;
            case 6:
                resultat = new String[]{"genres_livre", "id_genre", "nom_genre"};
                break;
            case 7:
                resultat = new String[]{"personnes", "id_personne", "full_name"};
                break;
            default:
                JOptionPane.showMessageDialog(null, "problème avec infoBDD", "Problème rencontré", JOptionPane.ERROR_MESSAGE);
                break;
        }
        return resultat;
    }
    
    private String[] infoAutreArticleBDD(int index) {
        String[] resultat = null;
        switch (index) {
            case 0:
                resultat = new String[]{"media_audio_genres", "id_media_audio", "id_genre_audio"};
                break;
            case 1:
                resultat = new String[]{"media_film_genres", "id_media_film", "	id_genre_film"};
                break;
            case 2:
                resultat = new String[]{"media_livre_genres", "id_media_livre", "id_genre_livre"};
                break;
            case 3:
                resultat = new String[]{"p_acteurs", "id_acteur", "id_media_film"};
                break;
            case 4:
                resultat = new String[]{"p_auteurs", "id_auteur", "id_media_livre"};
                break;
            case 5:
                resultat = new String[]{"p_interpretes", "id_interprete", "id_media_audio"};
                break;
            default:
                JOptionPane.showMessageDialog(null, "problème avec infoAutreArticleBDD", "Problème rencontré", JOptionPane.ERROR_MESSAGE);
                break;
        }
        return resultat;
    }

    public ArrayList<Autre> getListAutre(int autreSelected) {
        String[] tableauInfoBDD = infoBDD(autreSelected);
        String nomTab = tableauInfoBDD[0];
        String idColonne = tableauInfoBDD[1];
        String nomColonne = tableauInfoBDD[2];
        this.intanceAutre.recupAutreDB(nomTab, idColonne, nomColonne);
        return this.intanceAutre.getListAutre();
    }
    
   public ArrayList<Autre> getListAutreMinusArticle(int autreSelected, String tabJoin) {
        String[] tableauInfoBDD = infoBDD(autreSelected);
        String nomTab = tableauInfoBDD[0];
        String idColonne = tableauInfoBDD[1];
        String nomColonne = tableauInfoBDD[2];
        this.intanceAutre.recupAutreMinusArticleDB(nomTab, idColonne, nomColonne, tabJoin);
        return this.intanceAutre.getListAutre();
    }

    public boolean modAutre(int autreSelected, int idModAutre, String textModAutre) {
        String[] tableauInfoBDD = infoBDD(autreSelected);
        String request = "UPDATE " + tableauInfoBDD[0] + " SET " + tableauInfoBDD[2] + "=? WHERE " + tableauInfoBDD[1] + "=?";
        return this.intanceAutre.modAutreDB(idModAutre, textModAutre, request);
    }

    public boolean supAutre(int autreSelected, ArrayList<Autre> supList) {
        String[] tableauInfoBDD = infoBDD(autreSelected);
        String request = "DELETE FROM " + tableauInfoBDD[0] + " WHERE " + tableauInfoBDD[1];
        if (supList.size() == 1) {
            request += " = " + supList.get(0).getId();
        } else {
            request += " in (" + supList.get(0).getId();
            for (int i = 1; i < supList.size(); i++) {
                request += "," + supList.get(i).getId();
            }
            request += ")";
        }
        return this.intanceAutre.supAutreDB(request);
    }

    public boolean addAutre(int autreSelected, ArrayList<String> addList) {
        String[] tableauInfoBDD = infoBDD(autreSelected);
        String request = "INSERT INTO " + tableauInfoBDD[0] + " (" + tableauInfoBDD[2] + ") VALUES ";
        request += " ('" + addList.get(0) + "')";
        if (addList.size() > 1) {
            for (int i = 1; i < addList.size(); i++) {
                request += ",('" + addList.get(i) +"')";
            }
        }
        return this.intanceAutre.addAutreDB(request);
    }
    
    public boolean addAutreArticle(int autreArticleSelected, int id1, int id2){
        String[] tableauInfoBDD = infoAutreArticleBDD(autreArticleSelected);
        String request = "INSERT INTO "+ tableauInfoBDD[0] + " ("+ tableauInfoBDD[1]+", "+tableauInfoBDD[2]+") VALUES (?, ?)";       
        return this.intanceAutre.addAutreArticleDB(request, id1, id2);
    }
    
    public boolean supAutreArticle(int autreArticleSelected, int id1, int id2){
        String[] tableauInfoBDD = infoAutreArticleBDD(autreArticleSelected);
        String request = "DELETE FROM "+ tableauInfoBDD[0] + " WHERE "+ tableauInfoBDD[1]+"=? AND "+tableauInfoBDD[2]+"=? ";       
        return this.intanceAutre.supAutreArticleDB(request, id1, id2);
    }
}
