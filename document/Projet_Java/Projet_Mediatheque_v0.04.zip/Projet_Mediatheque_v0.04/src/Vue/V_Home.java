/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;

import Class.Commande;
import Class.Media;
import Class.User;
import Control.C_Autre;
import Control.C_Commande;
import Control.C_Media;
import Control.C_Media_Livre;
import Control.C_User;
import Util.CenterColumnTable;
import Util.KeyBinding;
import Util.TextFilter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author Panzzer
 */
public final class V_Home extends javax.swing.JFrame {

    private final C_User user;
    private final C_Media media = new C_Media();
    private final C_Autre autre = new C_Autre();
    private final C_Media_Livre livre = new C_Media_Livre();
    private final C_Commande commande = new C_Commande();
    private final V_AddMod_User modUser = new V_AddMod_User("Modifier", this);
    private final V_AddMod_User ajouUser = new V_AddMod_User("Ajouter", this);
    private final V_Mod_MediaLivre modLivre = new V_Mod_MediaLivre(autre, livre, this);
    private final V_Add_MediaLivre ajouLivre = new V_Add_MediaLivre(autre, livre, modLivre);
    private final V_Gerer_Autre gererAutre = new V_Gerer_Autre(autre);
    private final V_Detail_Commande detailCommande = new V_Detail_Commande();
    private int idUserSelect = 0;
    private String pseudoUserSelect = "";
    private int idMediaSelect = 0;
    private String nomArticleSelect = "";
    private int idCommandeSelect = 0;

    /**
     *
     * @param user
     */
    public V_Home(C_User user) {
        initComponents();
        posFen();
        this.user = user;
        labHello.setText("Bonjour " + this.user.getInstanceUser().getPseudo());
        remplirTableUser();

        CenterColumnTable.centerTableUser(tabUser);

        CenterColumnTable.centerTableArticle(tabArticle);

        CenterColumnTable.centerTableCommande(tabCommande);
        KeyBinding.addKeyBinding(this.jPanBackground, KeyEvent.VK_ENTER, "valider", (evt) -> {
            int index = jPanHome.getSelectedIndex();
            if (index == 1) {
                remplirTableUser();
            }
            if (index == 2) {
                filtreArticle();
            }
        });
        TextFilter.addTextFilterTable(tabUser, textFilterUser);
        TextFilter.addTextFilterTable(tabArticle, textFilterArticle);
        TextFilter.addTextFilterTable(tabCommande, textFilterCommande);
    }

    public C_User getUser() {
        return user;
    }

    public final void posFen() {
        this.setLocationRelativeTo(this.getParent());
    }

    public void remplirTableUser() {
        ArrayList<User> listUser = user.getListUser();
        DefaultTableModel model = (DefaultTableModel) tabUser.getModel();
        Object row[] = new Object[4];
        model.setRowCount(0);
        for (int i = 0; i < listUser.size(); i++) {
            row[0] = listUser.get(i).getPseudo();
            row[1] = listUser.get(i).getEmail();
            row[2] = listUser.get(i).getDroit();
            row[3] = listUser.get(i).getId();
            model.addRow(row);
        }
        idUserSelect = 0;
    }

    private void remplirTableMedia() {
        ArrayList<Media> listMedia = media.getIntanceMedia().getListMedia();
        DefaultTableModel model = (DefaultTableModel) tabArticle.getModel();
        Object row[] = new Object[6];
        model.setRowCount(0);
        for (int i = 0; i < listMedia.size(); i++) {
            String testEtat = listMedia.get(i).getEtat();
            if ("a".equals(testEtat)) {
                testEtat = "acceptable";
            }
            if ("b".equals(testEtat)) {
                testEtat = "bloqué";
            }
            if ("w".equals(testEtat)) {
                testEtat = "en attente";
            }
            int testSupport = listMedia.get(i).getIdSupport();
            String nameSupport = "";
            if (testSupport == 1) {
                nameSupport = "physique";
            }
            if (testSupport == 2) {
                nameSupport = "numérique";
            }
            row[0] = listMedia.get(i).getTitre();
            row[1] = listMedia.get(i).getPrix();
            row[2] = testEtat;
            row[3] = listMedia.get(i).getStock();
            row[4] = nameSupport;
            row[5] = listMedia.get(i).getIdMedia();
            model.addRow(row);
        }
        idMediaSelect = 0;
    }

    private void remplirTabCommande() {
        ArrayList<Commande> listCommande = commande.recupCommande();
        DefaultTableModel model = (DefaultTableModel) tabCommande.getModel();
        Object row[] = new Object[4];
        model.setRowCount(0);
        for (int i = 0; i < listCommande.size(); i++) {
            row[0] = listCommande.get(i).getIdCommande();
            row[1] = listCommande.get(i).getDateCommande();
            row[2] = listCommande.get(i).getLogin();
            row[3] = listCommande.get(i).getTotal();
            model.addRow(row);
        }
        idCommandeSelect = 0;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        groupTypeArticle = new javax.swing.ButtonGroup();
        groupStok = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jPanBackground = new javax.swing.JPanel();
        labHello = new javax.swing.JLabel();
        jPanHome = new javax.swing.JTabbedPane();
        jPanClient = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabUser = new javax.swing.JTable();
        butAddUser = new javax.swing.JButton();
        butModUser = new javax.swing.JButton();
        butFermer1 = new javax.swing.JButton();
        butSupUser = new javax.swing.JButton();
        butActuUser = new javax.swing.JButton();
        butAffCom = new javax.swing.JButton();
        textFilterUser = new javax.swing.JTextField();
        labSearchUser = new javax.swing.JLabel();
        jPanArticle = new javax.swing.JPanel();
        radioButLivre = new javax.swing.JRadioButton();
        radioButFilm = new javax.swing.JRadioButton();
        radioButMusic = new javax.swing.JRadioButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabArticle = new javax.swing.JTable();
        checkBoxPhysique = new javax.swing.JCheckBox();
        checkBoxNum = new javax.swing.JCheckBox();
        checkBoxAcc = new javax.swing.JCheckBox();
        checkBoxBlo = new javax.swing.JCheckBox();
        checkBoxAtt = new javax.swing.JCheckBox();
        labStock = new javax.swing.JLabel();
        radioButOui = new javax.swing.JRadioButton();
        radioButNon = new javax.swing.JRadioButton();
        radioButMoinsDe = new javax.swing.JRadioButton();
        butFiltreArticle = new javax.swing.JButton();
        textNumStok = new javax.swing.JTextField();
        comboBoxAddMedia = new javax.swing.JComboBox<>();
        butAjouArticle = new javax.swing.JButton();
        butModArticle = new javax.swing.JButton();
        butSupArticle = new javax.swing.JButton();
        butGestionAutre = new javax.swing.JButton();
        comboBoxGestionAutre = new javax.swing.JComboBox<>();
        butFermer2 = new javax.swing.JButton();
        textFilterArticle = new javax.swing.JTextField();
        labSearchArticle = new javax.swing.JLabel();
        jPanCommande = new javax.swing.JPanel();
        butFermer3 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabCommande = new javax.swing.JTable();
        textFilterCommande = new javax.swing.JTextField();
        labSearchCommande = new javax.swing.JLabel();
        butActuTabCommande = new javax.swing.JButton();
        butDetail = new javax.swing.JButton();
        butDeco = new javax.swing.JButton();

        jLabel1.setText("jLabel1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(700, 487));
        setResizable(false);

        jPanBackground.setPreferredSize(new java.awt.Dimension(700, 487));

        labHello.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        labHello.setText("hello");

        jPanHome.setPreferredSize(new java.awt.Dimension(700, 487));

        tabUser.setAutoCreateRowSorter(true);
        tabUser.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        tabUser.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Nom utilisateur", "Adresse email", "Droit", "id"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabUser.setRowHeight(20);
        tabUser.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tabUser.getTableHeader().setReorderingAllowed(false);
        tabUser.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tabUserMousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(tabUser);
        if (tabUser.getColumnModel().getColumnCount() > 0) {
            tabUser.getColumnModel().getColumn(2).setMaxWidth(100);
            tabUser.getColumnModel().getColumn(3).setPreferredWidth(100);
            tabUser.getColumnModel().getColumn(3).setMaxWidth(200);
        }

        butAddUser.setText("Ajouter");
        butAddUser.setFocusable(false);
        butAddUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butAddUserActionPerformed(evt);
            }
        });

        butModUser.setText("Modifier");
        butModUser.setFocusable(false);
        butModUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butModUserActionPerformed(evt);
            }
        });

        butFermer1.setText("Fermer");
        butFermer1.setFocusable(false);
        butFermer1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butFermer1ActionPerformed(evt);
            }
        });

        butSupUser.setText("Supprimer");
        butSupUser.setFocusable(false);
        butSupUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butSupUserActionPerformed(evt);
            }
        });

        butActuUser.setText("Actualiser");
        butActuUser.setFocusable(false);
        butActuUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butActuUserActionPerformed(evt);
            }
        });

        butAffCom.setText("Afficher les commandes");
        butAffCom.setFocusable(false);
        butAffCom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butAffComActionPerformed(evt);
            }
        });

        labSearchUser.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labSearchUser.setText("Rechercher :");

        javax.swing.GroupLayout jPanClientLayout = new javax.swing.GroupLayout(jPanClient);
        jPanClient.setLayout(jPanClientLayout);
        jPanClientLayout.setHorizontalGroup(
            jPanClientLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
            .addGroup(jPanClientLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanClientLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanClientLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(butAddUser, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(labSearchUser, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanClientLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(textFilterUser)
                    .addComponent(butModUser, javax.swing.GroupLayout.DEFAULT_SIZE, 94, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanClientLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanClientLayout.createSequentialGroup()
                        .addComponent(butSupUser)
                        .addGap(18, 18, 18)
                        .addComponent(butActuUser, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(butAffCom, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(166, 166, 166)
                .addComponent(butFermer1)
                .addContainerGap())
        );
        jPanClientLayout.setVerticalGroup(
            jPanClientLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanClientLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanClientLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanClientLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanClientLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(butAddUser)
                            .addComponent(butModUser)
                            .addComponent(butSupUser)
                            .addComponent(butActuUser))
                        .addGap(18, 18, 18)
                        .addGroup(jPanClientLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(butAffCom)
                            .addComponent(textFilterUser, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labSearchUser, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(28, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanClientLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(butFermer1)
                        .addContainerGap())))
        );

        jPanHome.addTab("Utilisateurs", jPanClient);

        groupTypeArticle.add(radioButLivre);
        radioButLivre.setSelected(true);
        radioButLivre.setText("Livres");
        radioButLivre.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                radioButLivreItemStateChanged(evt);
            }
        });

        groupTypeArticle.add(radioButFilm);
        radioButFilm.setText("Films");
        radioButFilm.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                radioButFilmItemStateChanged(evt);
            }
        });

        groupTypeArticle.add(radioButMusic);
        radioButMusic.setText("Musiques");
        radioButMusic.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                radioButMusicItemStateChanged(evt);
            }
        });

        tabArticle.setAutoCreateRowSorter(true);
        tabArticle.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        tabArticle.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Titre", "Prix", "Etat", "Stock", "Support", "id"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Double.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabArticle.setRowHeight(20);
        tabArticle.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tabArticle.getTableHeader().setReorderingAllowed(false);
        tabArticle.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tabArticleMousePressed(evt);
            }
        });
        jScrollPane2.setViewportView(tabArticle);
        if (tabArticle.getColumnModel().getColumnCount() > 0) {
            tabArticle.getColumnModel().getColumn(0).setPreferredWidth(300);
            tabArticle.getColumnModel().getColumn(2).setPreferredWidth(150);
            tabArticle.getColumnModel().getColumn(4).setPreferredWidth(150);
        }

        checkBoxPhysique.setText("Physique");

        checkBoxNum.setText("Numérique");

        checkBoxAcc.setText("Acceptable");

        checkBoxBlo.setText("Bloqué");

        checkBoxAtt.setText("En attente");

        labStock.setText("En stoque");

        groupStok.add(radioButOui);
        radioButOui.setSelected(true);
        radioButOui.setText("Oui");

        groupStok.add(radioButNon);
        radioButNon.setText("Non");

        groupStok.add(radioButMoinsDe);
        radioButMoinsDe.setText("Moins de ");

        butFiltreArticle.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        butFiltreArticle.setText("Filtrer");
        butFiltreArticle.setFocusable(false);
        butFiltreArticle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butFiltreArticleActionPerformed(evt);
            }
        });

        textNumStok.setText("1");

        comboBoxAddMedia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "un Livre", "un Film", "une Musique" }));

        butAjouArticle.setText("Ajouter");
        butAjouArticle.setFocusable(false);
        butAjouArticle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butAjouArticleActionPerformed(evt);
            }
        });

        butModArticle.setText("Modifier");
        butModArticle.setFocusable(false);
        butModArticle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butModArticleActionPerformed(evt);
            }
        });

        butSupArticle.setText("Supprimer");
        butSupArticle.setFocusable(false);
        butSupArticle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butSupArticleActionPerformed(evt);
            }
        });

        butGestionAutre.setText("Gérer les");
        butGestionAutre.setFocusable(false);
        butGestionAutre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butGestionAutreActionPerformed(evt);
            }
        });

        comboBoxGestionAutre.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "éditeurs", "formats audio", "formats film", "formats livre", "genres audio", "genres film", "genres livre", "personnes" }));

        butFermer2.setText("Fermer");
        butFermer2.setFocusable(false);
        butFermer2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butFermer2ActionPerformed(evt);
            }
        });

        labSearchArticle.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        labSearchArticle.setText("Rechercher :");

        javax.swing.GroupLayout jPanArticleLayout = new javax.swing.GroupLayout(jPanArticle);
        jPanArticle.setLayout(jPanArticleLayout);
        jPanArticleLayout.setHorizontalGroup(
            jPanArticleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2)
            .addGroup(jPanArticleLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanArticleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanArticleLayout.createSequentialGroup()
                        .addGroup(jPanArticleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanArticleLayout.createSequentialGroup()
                                .addComponent(radioButLivre)
                                .addGap(18, 18, 18)
                                .addComponent(radioButFilm)
                                .addGap(18, 18, 18)
                                .addComponent(radioButMusic))
                            .addGroup(jPanArticleLayout.createSequentialGroup()
                                .addGroup(jPanArticleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(checkBoxAcc)
                                    .addGroup(jPanArticleLayout.createSequentialGroup()
                                        .addGap(21, 21, 21)
                                        .addComponent(labStock))
                                    .addComponent(checkBoxPhysique))
                                .addGap(18, 18, 18)
                                .addGroup(jPanArticleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(checkBoxNum)
                                    .addGroup(jPanArticleLayout.createSequentialGroup()
                                        .addComponent(checkBoxBlo)
                                        .addGap(18, 18, 18)
                                        .addComponent(checkBoxAtt))
                                    .addGroup(jPanArticleLayout.createSequentialGroup()
                                        .addComponent(radioButOui)
                                        .addGap(18, 18, 18)
                                        .addComponent(radioButNon)
                                        .addGap(18, 18, 18)
                                        .addComponent(radioButMoinsDe)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textNumStok, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(butFiltreArticle, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(53, 53, 53)
                        .addGroup(jPanArticleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(butSupArticle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(butModArticle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanArticleLayout.createSequentialGroup()
                        .addGroup(jPanArticleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(butGestionAutre, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(butAjouArticle, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanArticleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(comboBoxGestionAutre, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(comboBoxAddMedia, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(jPanArticleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanArticleLayout.createSequentialGroup()
                                .addGap(55, 55, 55)
                                .addComponent(labSearchArticle, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textFilterArticle, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(224, 224, 224))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanArticleLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(butFermer2)))))
                .addContainerGap())
        );
        jPanArticleLayout.setVerticalGroup(
            jPanArticleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanArticleLayout.createSequentialGroup()
                .addGroup(jPanArticleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanArticleLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanArticleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(radioButLivre)
                            .addComponent(radioButFilm)
                            .addComponent(radioButMusic))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanArticleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(checkBoxPhysique)
                            .addComponent(checkBoxNum))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanArticleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(checkBoxAcc)
                            .addComponent(checkBoxBlo)
                            .addComponent(checkBoxAtt))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanArticleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labStock)
                            .addComponent(radioButOui)
                            .addComponent(radioButNon)
                            .addComponent(radioButMoinsDe)
                            .addComponent(textNumStok, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanArticleLayout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(jPanArticleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanArticleLayout.createSequentialGroup()
                                .addComponent(butModArticle)
                                .addGap(18, 18, 18)
                                .addComponent(butSupArticle))
                            .addComponent(butFiltreArticle, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanArticleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE, false)
                    .addComponent(butAjouArticle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(comboBoxAddMedia)
                    .addComponent(textFilterArticle, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labSearchArticle, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addGroup(jPanArticleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(butGestionAutre)
                    .addComponent(comboBoxGestionAutre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(butFermer2))
                .addContainerGap())
        );

        jPanHome.addTab("Articles", jPanArticle);

        butFermer3.setText("Fermer");
        butFermer3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butFermer3ActionPerformed(evt);
            }
        });

        tabCommande.setAutoCreateRowSorter(true);
        tabCommande.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id", "Date - Heure", "Client", "Prix Total"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Double.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabCommande.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tabCommande.getTableHeader().setReorderingAllowed(false);
        tabCommande.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tabCommandeMousePressed(evt);
            }
        });
        jScrollPane3.setViewportView(tabCommande);
        if (tabCommande.getColumnModel().getColumnCount() > 0) {
            tabCommande.getColumnModel().getColumn(0).setResizable(false);
            tabCommande.getColumnModel().getColumn(0).setPreferredWidth(10);
            tabCommande.getColumnModel().getColumn(1).setResizable(false);
            tabCommande.getColumnModel().getColumn(2).setResizable(false);
            tabCommande.getColumnModel().getColumn(3).setResizable(false);
        }

        labSearchCommande.setText("Recherche :");

        butActuTabCommande.setText("Actualiser");
        butActuTabCommande.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butActuTabCommandeActionPerformed(evt);
            }
        });

        butDetail.setText("Détail");
        butDetail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butDetailActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanCommandeLayout = new javax.swing.GroupLayout(jPanCommande);
        jPanCommande.setLayout(jPanCommandeLayout);
        jPanCommandeLayout.setHorizontalGroup(
            jPanCommandeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3)
            .addGroup(jPanCommandeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(labSearchCommande)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(textFilterCommande, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(51, 51, 51)
                .addComponent(butActuTabCommande, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanCommandeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanCommandeLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(butFermer3)
                        .addContainerGap())
                    .addGroup(jPanCommandeLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(butDetail, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(234, Short.MAX_VALUE))))
        );
        jPanCommandeLayout.setVerticalGroup(
            jPanCommandeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanCommandeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 351, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanCommandeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textFilterCommande, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labSearchCommande)
                    .addComponent(butActuTabCommande)
                    .addComponent(butDetail))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(butFermer3)
                .addContainerGap())
        );

        jPanHome.addTab("Commandes", jPanCommande);

        butDeco.setText("Déconnexion");
        butDeco.setFocusable(false);
        butDeco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butDecoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanBackgroundLayout = new javax.swing.GroupLayout(jPanBackground);
        jPanBackground.setLayout(jPanBackgroundLayout);
        jPanBackgroundLayout.setHorizontalGroup(
            jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanBackgroundLayout.createSequentialGroup()
                .addGap(190, 190, 190)
                .addComponent(labHello, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(butDeco)
                .addContainerGap())
            .addComponent(jPanHome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanBackgroundLayout.setVerticalGroup(
            jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanBackgroundLayout.createSequentialGroup()
                .addGroup(jPanBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labHello)
                    .addComponent(butDeco))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanHome, javax.swing.GroupLayout.PREFERRED_SIZE, 479, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanBackground, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanBackground, javax.swing.GroupLayout.DEFAULT_SIZE, 511, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void butFermer1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butFermer1ActionPerformed
        fermerAction();
    }//GEN-LAST:event_butFermer1ActionPerformed

    // action pour fermer le programme par un confirm
    private void fermerAction() {
        if (JOptionPane.showConfirmDialog(this, "Êtes vous sur de vouloir fermer le programme", "Fermeture", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
            System.exit(0);
        }
    }

    // ouvre la fenetre pour ajouter un utilisateur avec l affichage selon admin ou superAdmin
    private void butAddUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butAddUserActionPerformed
        ajouUser.hideBoxAdmin("s".equals(user.getInstanceUser().getDroit()));
        ajouUser.setVisible(true);
        ajouUser.posFen(210, 200);
        ajouUser.setHome(this);
    }//GEN-LAST:event_butAddUserActionPerformed

    private void butModUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butModUserActionPerformed
        ouvrirModUser();
    }//GEN-LAST:event_butModUserActionPerformed

    // ouvre la fenetre pour modifier un utilisateur avec l affichage selon admin ou superAdmin
    private void ouvrirModUser() {
        modUser.hideBoxAdmin("s".equals(user.getInstanceUser().getDroit()));
        modUser.setVisible(true);
        modUser.posFen(1350, 200);
        modUser.setHome(this);
    }

    private void butDecoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butDecoActionPerformed
        decoAction();
    }//GEN-LAST:event_butDecoActionPerformed

    // action pour déconnecté par un confirm
    private void decoAction() {
        if (JOptionPane.showConfirmDialog(this, "Êtes vous sur de vouloir vous déconnecter", "Déconnection", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
            V_Login log = new V_Login();
            log.setVisible(true);
            modUser.dispose();
            ajouUser.dispose();
            this.dispose();
        }
    }

    // affiche les commandes de l'utilisateur choisi
    private void butAffComActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butAffComActionPerformed
        jPanHome.setSelectedIndex(2);
    }//GEN-LAST:event_butAffComActionPerformed

    private void butActuUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butActuUserActionPerformed
        remplirTableUser();
    }//GEN-LAST:event_butActuUserActionPerformed

    private void butSupUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butSupUserActionPerformed
        supprimerUser();
    }//GEN-LAST:event_butSupUserActionPerformed

    // test si une ligne du tableau User a été sélectionné puis lance un comfirm pour la suppression d'un User
    private void supprimerUser() {
        if (this.idUserSelect != 0) {
            if (JOptionPane.showConfirmDialog(this, "Êtes vous sur de vouloir supprimer le compte de " + this.pseudoUserSelect, "Suppression", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
                if (user.suppUser(this.idUserSelect)) {
                    remplirTableUser();
                    JOptionPane.showMessageDialog(this, "Le compte utilisateur à été corectement supprimé", "Suppression", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez choisir un utilisateur à supprimer dans le tableau", "Erreur", JOptionPane.WARNING_MESSAGE);
        }
    }

    // evenement du click sur le tableau User qui envoi les info de la ligne selectionné vers la fenetre Modifier User et sauvegarde l'id de cette ligne
    private void tabUserMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabUserMousePressed
        int iView = tabUser.getSelectedRow();
        int i = tabUser.convertRowIndexToModel(iView);
        TableModel model = tabUser.getModel();
        int id = (int) model.getValueAt(i, 3);
        String login = (String) model.getValueAt(i, 0);
        String email = (String) model.getValueAt(i, 1);
        String droit = (String) model.getValueAt(i, 2);
        this.idUserSelect = id;
        this.pseudoUserSelect = login;
        modUser.setTextPseudo(login);
        modUser.setTextEmail(email);
        modUser.setIdUser(id);
        modUser.setboxAdmin(("a".equals(droit)));

        tabUser.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent mouseEvent) {
                if (mouseEvent.getClickCount() == 2) {
                    ouvrirModUser();
                }
            }
        });
    }//GEN-LAST:event_tabUserMousePressed

    private void butFiltreArticleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butFiltreArticleActionPerformed
        filtreArticle();
    }//GEN-LAST:event_butFiltreArticleActionPerformed

    // verifie le formulaire de l'onglet aricle avant l'envoi d'une requete
    public void filtreArticle() {
        String text = textNumStok.getText();
        int numStok;
        boolean test;

        if (!checkBoxPhysique.isSelected() && !checkBoxNum.isSelected()) {
            JOptionPane.showMessageDialog(this, "Veuillez choisir au moins un type de support", "Erreur", JOptionPane.WARNING_MESSAGE);
            test = false;
        } else {
            test = true;
        }

        if (!checkBoxAcc.isSelected() && !checkBoxAtt.isSelected() && !checkBoxBlo.isSelected()) {
            JOptionPane.showMessageDialog(this, "Veuillez choisir au moins un type d'état", "Erreur", JOptionPane.WARNING_MESSAGE);
            test = false;
        }

        if (radioButMoinsDe.isSelected()) {
            try {
                numStok = Integer.parseInt(text);
                if (numStok < 0) {
                    JOptionPane.showMessageDialog(this, "Veuillez choisir une valeur supérieur à zero pour le stoque", "Erreur", JOptionPane.WARNING_MESSAGE);
                    test = false;
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Veuillez choisir un nombre valide pour le stoque", "Erreur", JOptionPane.WARNING_MESSAGE);
                test = false;
            }

        }
        if (test) {
            getChoixArticle();
        }
    }

    // envoi les valeurs pour faire la requete sur les articles
    private void getChoixArticle() {
        String typeArticle = "";
        boolean physique = checkBoxPhysique.isSelected();
        boolean numerique = checkBoxNum.isSelected();
        boolean acceptable = checkBoxAcc.isSelected();
        boolean bloque = checkBoxBlo.isSelected();
        boolean enAttente = checkBoxAtt.isSelected();
        int stock = 0;
        if (radioButLivre.isSelected()) {
            typeArticle = "media_livre";
        }
        if (radioButFilm.isSelected()) {
            typeArticle = "media_film";
        }
        if (radioButMusic.isSelected()) {
            typeArticle = "media_audio";
        }
        if (radioButOui.isSelected()) {
            stock = -1;
        }
        if (radioButNon.isSelected()) {
            stock = 0;
        }
        if (radioButMoinsDe.isSelected()) {
            stock = Integer.parseInt(textNumStok.getText());
        }
        media.getListMedia(typeArticle, physique, numerique, acceptable, bloque, enAttente, stock);
        remplirTableMedia();
    }

    public void setFilter(int type, int support, int etat, int stock) {
        switch (type) {
            case 1:
                radioButLivre.setSelected(true);
                break;
            case 2:
                radioButFilm.setSelected(true);
                break;
            default:
                radioButMusic.setSelected(true);
                break;
        }

        if (support == 1) {
            checkBoxPhysique.setSelected(true);
            checkBoxNum.setSelected(false);
        } else {
            checkBoxPhysique.setSelected(false);
            checkBoxNum.setSelected(true);
        }

        switch (etat) {
            case 1:
                checkBoxAcc.setSelected(true);
                checkBoxBlo.setSelected(false);
                checkBoxAtt.setSelected(false);
                break;
            case 2:
                checkBoxAcc.setSelected(false);
                checkBoxBlo.setSelected(true);
                checkBoxAtt.setSelected(false);
                break;
            default:
                checkBoxAcc.setSelected(false);
                checkBoxBlo.setSelected(false);
                checkBoxAtt.setSelected(true);
                break;
        }

        if (stock == 0) {
            radioButNon.setSelected(true);
        } else {
            radioButOui.setSelected(true);
        }
    }

    private void butSupArticleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butSupArticleActionPerformed
        supprimerArticle();
    }//GEN-LAST:event_butSupArticleActionPerformed

    // test si une ligne du tableau Article a été sélectionné puis lance un comfirm pour la suppression d'un Article
    private void supprimerArticle() {
        if (this.idMediaSelect != 0) {
            if (JOptionPane.showConfirmDialog(this, "Êtes vous sur de vouloir supprimer cet Article :  " + this.nomArticleSelect, "Suppression", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
                if (livre.supLivre(this.idMediaSelect)) {
                    JOptionPane.showMessageDialog(this, "Le livre à été corectement supprimé", "Suppression", JOptionPane.INFORMATION_MESSAGE);
                    filtreArticle();
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez choisir un Article à supprimer dans le tableau", "Erreur", JOptionPane.WARNING_MESSAGE);
        }
    }

    //evenement du click sur le tableau Article qui envoi l'id de la ligne selectionné vers la fenetre Modifier Article et sauvegarde l'id de cette ligne
    private void tabArticleMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabArticleMousePressed
        int iView = tabArticle.getSelectedRow();
        int i = tabArticle.convertRowIndexToModel(iView);
        TableModel model = tabArticle.getModel();
        int id = (int) model.getValueAt(i, 5);
        String nom = (String) model.getValueAt(i, 0);
        this.idMediaSelect = id;
        this.nomArticleSelect = nom;
        modLivre.setIdLivre(this.idMediaSelect);
        modLivre.setComboBox();
        modLivre.setLivre();
        modLivre.setList();
        tabArticle.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent mouseEvent) {
                if (mouseEvent.getClickCount() == 2) {
                    ouvrirModArticle();
                }
            }
        });
    }//GEN-LAST:event_tabArticleMousePressed

    private void butGestionAutreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butGestionAutreActionPerformed
        gererAutre.setComboBoxChoix(comboBoxGestionAutre.getSelectedIndex());
        gererAutre.remplirListComplete();
        gererAutre.setVisible(true);
    }//GEN-LAST:event_butGestionAutreActionPerformed

    private void butFermer2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butFermer2ActionPerformed
        fermerAction();
    }//GEN-LAST:event_butFermer2ActionPerformed

    private void radioButLivreItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_radioButLivreItemStateChanged
        if (radioButLivre.isSelected()) {
            resetTabArticle();
        }
    }//GEN-LAST:event_radioButLivreItemStateChanged

    private void radioButFilmItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_radioButFilmItemStateChanged
        if (radioButFilm.isSelected()) {
            resetTabArticle();
        }
    }//GEN-LAST:event_radioButFilmItemStateChanged

    private void radioButMusicItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_radioButMusicItemStateChanged
        if (radioButMusic.isSelected()) {
            resetTabArticle();
        }
    }//GEN-LAST:event_radioButMusicItemStateChanged

    // réinitialise le tabArticle à 0 ligne et la valeur de l'idMediaSelect à 0
    private void resetTabArticle() {
        DefaultTableModel model = (DefaultTableModel) tabArticle.getModel();
        model.setRowCount(0);
        idMediaSelect = 0;
    }

    private void butModArticleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butModArticleActionPerformed
        ouvrirModArticle();
    }//GEN-LAST:event_butModArticleActionPerformed

    private void ouvrirModArticle() {
        if (this.idMediaSelect != 0) {
            if (this.radioButLivre.isSelected()) {
                modLivre.setVisible(true);
            }

            // TODO traiter les cas FIlm et Musique
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez choisir un Article à modifier dans le tableau", "Erreur", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void butAjouArticleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butAjouArticleActionPerformed
        if (comboBoxAddMedia.getSelectedIndex() == 0) {
            ajouLivre.setComboBox();
            ajouLivre.setVisible(true);
        }

        // TODO traiter les cas Film et Musique

    }//GEN-LAST:event_butAjouArticleActionPerformed

    private void butFermer3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butFermer3ActionPerformed
        fermerAction();
    }//GEN-LAST:event_butFermer3ActionPerformed

    private void butActuTabCommandeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butActuTabCommandeActionPerformed
        remplirTabCommande();
    }//GEN-LAST:event_butActuTabCommandeActionPerformed

    private void butDetailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butDetailActionPerformed
        ouvrirDetailCommande();
    }//GEN-LAST:event_butDetailActionPerformed

    private void tabCommandeMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabCommandeMousePressed
        int iView = tabCommande.getSelectedRow();
        int i = tabCommande.convertRowIndexToModel(iView);
        TableModel model = tabCommande.getModel();
        int id = (int) model.getValueAt(i, 0);
        this.idCommandeSelect = id;
        String date = (String) model.getValueAt(i, 1);
        String client = (String) model.getValueAt(i, 2);
        double prixTotalHT = (double) model.getValueAt(i, 3);
        try {
            this.detailCommande.setFacture(id, date, client, prixTotalHT);
        } catch (ParseException ex) {
            Logger.getLogger(V_Home.class.getName()).log(Level.SEVERE, null, ex);
        }
        tabCommande.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent mouseEvent) {
                if (mouseEvent.getClickCount() == 2) {
                    ouvrirDetailCommande();
                }
            }
        });
    }//GEN-LAST:event_tabCommandeMousePressed

    private void ouvrirDetailCommande() {
        if (this.idCommandeSelect != 0) {
            this.detailCommande.setVisible(true);
        }
    }

    /**
     * @param args the command line arguments
     */
//    public static void main(String args[]) {
//        /* Set the Nimbus look and feel */
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(V_Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(V_Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(V_Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(V_Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//
//        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new V_Home().setVisible(true);
//            }
//        });
//    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton butActuTabCommande;
    private javax.swing.JButton butActuUser;
    private javax.swing.JButton butAddUser;
    private javax.swing.JButton butAffCom;
    private javax.swing.JButton butAjouArticle;
    private javax.swing.JButton butDeco;
    private javax.swing.JButton butDetail;
    private javax.swing.JButton butFermer1;
    private javax.swing.JButton butFermer2;
    private javax.swing.JButton butFermer3;
    private javax.swing.JButton butFiltreArticle;
    private javax.swing.JButton butGestionAutre;
    private javax.swing.JButton butModArticle;
    private javax.swing.JButton butModUser;
    private javax.swing.JButton butSupArticle;
    private javax.swing.JButton butSupUser;
    private javax.swing.JCheckBox checkBoxAcc;
    private javax.swing.JCheckBox checkBoxAtt;
    private javax.swing.JCheckBox checkBoxBlo;
    private javax.swing.JCheckBox checkBoxNum;
    private javax.swing.JCheckBox checkBoxPhysique;
    private javax.swing.JComboBox<String> comboBoxAddMedia;
    private javax.swing.JComboBox<String> comboBoxGestionAutre;
    private javax.swing.ButtonGroup groupStok;
    private javax.swing.ButtonGroup groupTypeArticle;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanArticle;
    private javax.swing.JPanel jPanBackground;
    private javax.swing.JPanel jPanClient;
    private javax.swing.JPanel jPanCommande;
    private javax.swing.JTabbedPane jPanHome;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel labHello;
    private javax.swing.JLabel labSearchArticle;
    private javax.swing.JLabel labSearchCommande;
    private javax.swing.JLabel labSearchUser;
    private javax.swing.JLabel labStock;
    private javax.swing.JRadioButton radioButFilm;
    private javax.swing.JRadioButton radioButLivre;
    private javax.swing.JRadioButton radioButMoinsDe;
    private javax.swing.JRadioButton radioButMusic;
    private javax.swing.JRadioButton radioButNon;
    private javax.swing.JRadioButton radioButOui;
    private javax.swing.JTable tabArticle;
    private javax.swing.JTable tabCommande;
    private javax.swing.JTable tabUser;
    private javax.swing.JTextField textFilterArticle;
    private javax.swing.JTextField textFilterCommande;
    private javax.swing.JTextField textFilterUser;
    private javax.swing.JTextField textNumStok;
    // End of variables declaration//GEN-END:variables
}
