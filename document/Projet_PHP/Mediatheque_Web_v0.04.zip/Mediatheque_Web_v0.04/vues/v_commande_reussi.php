<div id="banner-wrapper">
    <div id="banner" class="box container">
        <div class="row">
            <div class="12u 12u(medium)">
                <p>Merci votre commande a été enregisté avec succès</p>
            </div>
        </div>
    </div>
</div>