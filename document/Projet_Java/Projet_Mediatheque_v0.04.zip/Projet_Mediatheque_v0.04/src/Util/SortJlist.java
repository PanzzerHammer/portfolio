/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Util;

import java.util.ArrayList;
import java.util.Collections;
import javax.swing.DefaultListModel;

/**
 *
 * @author Panzzer
 */
public abstract class SortJlist {
    
    public static DefaultListModel sortList(DefaultListModel jlist) {
        ArrayList liste = Collections.list(jlist.elements());
        Collections.sort(liste);
        jlist = new DefaultListModel();
        for (int i = 0; i < liste.size(); i++) {
            jlist.addElement(liste.get(i));
        }
        return jlist;
    }
}
