/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Class;

import Util.MySqlConnect;
import java.sql.CallableStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Panzzer
 */
public class Media_Livre extends Media {

    private String ISBN;
    private int idEditeur;
    private int idFormat;
    private Media_Livre livre;

    public Media_Livre(int idMedia, String titre, double prix, String etat, int annee, int stock, int idSupport, String ISBN, int idEditeur, int idFormat) {
        super(idMedia, titre, prix, etat, annee, stock, idSupport);
        this.ISBN = ISBN;
        this.idEditeur = idEditeur;
        this.idFormat = idFormat;
    }

    public Media_Livre() {
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public int getIdEditeur() {
        return idEditeur;
    }

    public void setIdEditeur(int idEditeur) {
        this.idEditeur = idEditeur;
    }

    public int getIdFormat() {
        return idFormat;
    }

    public void setIdFormat(int idFormat) {
        this.idFormat = idFormat;
    }

    public Media_Livre getLivre() {
        return livre;
    }

    public boolean recupMediaLivreDB(int id) {
        boolean test = false;
        String request = "SELECT media.id_media, media.titre, media.prix, media.etat, media.annee, media.stock, media.id_support,"
                + " media_livre.ISBN, media_livre.id_editeur, media_livre.id_format_livre FROM media"
                + " JOIN media_livre ON media.id_media = media_livre.id_media"
                + " WHERE media.id_media = ?";
        MySqlConnect.testConn();
        if (MySqlConnect.conn != null) {
            try {
                pst = MySqlConnect.conn.prepareStatement(request);
                pst.setInt(1, id);
                rs = pst.executeQuery();
                if (rs.next()) {
                    int idMediaR = rs.getInt("id_media");
                    String titreR = rs.getString("titre");
                    double prixR = rs.getDouble("prix");
                    String etatR = rs.getString("etat");
                    int anneeR = rs.getInt("annee");
                    int stockR = rs.getInt("stock");
                    int idSupportR = rs.getInt("id_support");
                    String ISBNR = rs.getString("ISBN");
                    int idEditeurR = rs.getInt("id_editeur");
                    int idFormatR = rs.getInt("id_format_livre");
                    this.livre = new Media_Livre(idMediaR, titreR, prixR, etatR, anneeR, stockR, idSupportR, ISBNR, idEditeurR, idFormatR);
                    test = true;
                }
                pst.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "problème avec recupMediaLivreDB()" + ex.getMessage(), "Problème rencontré",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
        return test;
    }

    public boolean modMediaLivreDB(int id, String isbn, int idEditeur, int idFormatLivre) {
        boolean testMod = false;
        String request = "UPDATE media_livre SET ISBN=?, id_editeur=?, id_format_livre=? WHERE id_media=?";
        MySqlConnect.testConn();
        if (MySqlConnect.conn != null) {
            try {
                pst = MySqlConnect.conn.prepareStatement(request);
                pst.setString(1, isbn);
                pst.setInt(2, idEditeur);
                pst.setInt(3, idFormatLivre);
                pst.setInt(4, id);
                pst.executeUpdate();
                testMod = true;
                pst.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "problème avec modMediaLivreDB()" + ex.getMessage(), "Problème rencontré",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
        return testMod;
    }

//    public void addMediaLivreDB(int id, String isbn, int idEditeur, int idFormatLivre) {
//        String request = "INSERT INTO media_livre(id_media, ISBN, id_editeur, id_format_livre) VALUE (?, ?, ?, ?)";
//        MySqlConnect.testConn();
//        if (MySqlConnect.conn != null) {
//            try {
//                pst = MySqlConnect.conn.prepareStatement(request);
//                pst.setInt(1, id);
//                pst.setString(2, isbn);
//                pst.setInt(3, idEditeur);
//                pst.setInt(4, idFormatLivre);
//                pst.executeUpdate();
//                JOptionPane.showMessageDialog(null, "Le Livre à été corectement ajouter", "Modification", JOptionPane.INFORMATION_MESSAGE);
//                pst.close();
//            } catch (SQLException ex) {
//                JOptionPane.showMessageDialog(null, "problème avec addMediaLivreDB()" + ex.getMessage(), "Problème rencontré",
//                        JOptionPane.ERROR_MESSAGE);
//            }
//        }
//    }
    
    public int addMedialLivreDB(String titre, double prix, String etat, int annee, int stock, int idSupport, String isbn, int idEditeur, int idFormatLivre) {
        int id = 0;
        String callProcedure = "{ call insert_media_livre(?, ?, ?, ?, ?, ?, ?, ?, ?, ?) }";
        MySqlConnect.testConn();
        if (MySqlConnect.conn != null) {
            try {
                CallableStatement cs = MySqlConnect.conn.prepareCall(callProcedure);
                cs.setString(1, titre);
                cs.setDouble(2, prix);
                cs.setString(3, etat);
                cs.setInt(4, annee);
                cs.setInt(5, stock);
                cs.setInt(6, idSupport);
                cs.setString(8, isbn);
                cs.setInt(9, idEditeur);
                cs.setInt(10, idFormatLivre);
                cs.registerOutParameter(7, java.sql.Types.INTEGER);
                cs.execute();
                id = cs.getInt(7);
                cs.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "problème avec addMediaLivreDB()" + ex.getMessage(), "Problème rencontré",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
        return id;
    }

    public boolean supMediaLivreDB(int id) {
        boolean test = false;
        String request = "DELETE FROM media_livre WHERE id_media =?";
        MySqlConnect.testConn();
        if (MySqlConnect.conn != null) {
            try {
                pst = MySqlConnect.conn.prepareStatement(request);
                pst.setInt(1, id);
                pst.executeUpdate();
                test = true;
                pst.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "problème avec supMediaLivreDB()" + ex.getMessage(), "Problème rencontré",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
        return test;
    }
}
