/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Util;

import com.placeholder.PlaceHolder;
import java.awt.Color;
import javax.swing.JTextField;

/**
 *
 * @author Panzzer
 */
public class StyleHolder {
    
    Color colorHolder = Color.LIGHT_GRAY;
    Color colorSimple = Color.BLACK;
    boolean italic = false;
    String font = "Tomaha";
    int size = 16;
    PlaceHolder holder;
    
        public StyleHolder (JTextField nomJT,String texteHolder){
            holder = new PlaceHolder(nomJT, colorHolder, colorSimple, texteHolder, italic, font, size);
        }
    
    
}
