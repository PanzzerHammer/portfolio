/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Class;

import Util.MySqlConnect;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Panzzer
 */
public class Media {

    protected int idMedia;
    protected String titre;
    protected double prix;
    protected String etat;
    protected int annee;
    protected int stock;
    protected int idSupport;
    protected PreparedStatement pst;
    protected ResultSet rs;
    protected ArrayList<Media> listMedia = new ArrayList<>();

    public Media(int idMedia, String titre, double prix, String etat, int annee, int stock, int idSupport) {
        this.idMedia = idMedia;
        this.titre = titre;
        this.prix = prix;
        this.etat = etat;
        this.annee = annee;
        this.stock = stock;
        this.idSupport = idSupport;
    }

    public Media() {
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public double getPrix() {
        return prix;
    }

    public void setPrix(double prix) {
        this.prix = prix;
    }

    public String getEtat() {
        return etat;
    }

    public void setEtat(String etat) {
        this.etat = etat;
    }

    public int getAnnee() {
        return annee;
    }

    public void setAnnee(int annee) {
        this.annee = annee;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public int getIdSupport() {
        return idSupport;
    }

    public void setIdSupport(int idSupport) {
        this.idSupport = idSupport;
    }

    public ArrayList<Media> getListMedia() {
        return listMedia;
    }

    public void setListMedia(ArrayList<Media> listMedia) {
        this.listMedia = listMedia;
    }

    public int getIdMedia() {
        return idMedia;
    }

    public void recupMediaDB(String typeMedia, String etatRequete, String option) {
        String request = "SELECT media.id_media, media.titre, media.prix, media.etat, media.annee, media.stock, media.id_support FROM media"
                + " JOIN " + typeMedia + " ON media.id_media = " + typeMedia + ".id_media"
                + " WHERE " + etatRequete + option;
        MySqlConnect.testConn();
        if (MySqlConnect.conn != null) {
            try {
                pst = MySqlConnect.conn.prepareStatement(request);
                rs = pst.executeQuery();
                this.listMedia = new ArrayList<>();
                while (rs.next()) {
                    int idMediaR = rs.getInt("id_media");
                    String titreR = rs.getString("titre");
                    double prixR = rs.getDouble("prix");
                    String etatR = rs.getString("etat");
                    int anneeR = rs.getInt("annee");
                    int stockR = rs.getInt("stock");
                    int idSupportR = rs.getInt("id_support");
                    this.listMedia.add(new Media(idMediaR, titreR, prixR, etatR, anneeR, stockR, idSupportR));
                }
                pst.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "problème avec recupMediaDB()" + ex.getMessage(), "Problème rencontré",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public boolean modMediaDB(int id, String titre, double prix, String etat, int annee, int stock, int idSupport) {
        boolean testMod = false;
        String request = "UPDATE media SET titre=?, prix=?, etat=?, annee=?, stock=?, id_support=? WHERE id_media=?";
        MySqlConnect.testConn();
        if (MySqlConnect.conn != null) {
            try {
                pst = MySqlConnect.conn.prepareStatement(request);
                pst.setString(1, titre);
                pst.setDouble(2, prix);
                pst.setString(3, etat);
                pst.setInt(4, annee);
                pst.setInt(5, stock);
                pst.setInt(6, idSupport);
                pst.setInt(7, id);
                pst.executeUpdate();
                testMod = true;
                pst.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "problème avec modMediaDB()" + ex.getMessage(), "Problème rencontré",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
        return testMod;
    }

//    public int addMediaDB(String titre, double prix, String etat, int annee, int stock, int idSupport) {
//        int idMediaAdd = 0;
//        String request = "INSERT INTO media (id_media, titre, prix, etat, annee, stock, id_support) VALUE (NULL, ?, ?, ?, ?, ?, ?)";
//        String []column ={"id_media"};
//        MySqlConnect.testConn();
//        if (MySqlConnect.conn != null) {
//            try {
//                pst = MySqlConnect.conn.prepareStatement(request, column);
//                pst.setString(1, titre);
//                pst.setDouble(2, prix);
//                pst.setString(3, etat);
//                pst.setInt(4, annee);
//                pst.setInt(5, stock);
//                pst.setInt(6, idSupport);
//                pst.executeUpdate();
//                rs = pst.getGeneratedKeys();
//                if (rs.next()) {
//                    idMediaAdd = rs.getInt(1);
//                }
//                pst.close();
//            } catch (SQLException ex) {
//                JOptionPane.showMessageDialog(null, "problème avec addMediaDB()" + ex.getMessage(), "Problème rencontré",
//                        JOptionPane.ERROR_MESSAGE);
//            }
//        }
//        return idMediaAdd;
//    }
}
