/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Class.Media_Livre;

/**
 *
 * @author Panzzer
 */
public class C_Media_Livre {

    private final Media_Livre instanceLivre = new Media_Livre();

    public C_Media_Livre() {
    }

    public Media_Livre getInstanceLivre() {
        return instanceLivre;
    }

    public boolean getLivre(int id) {
        return instanceLivre.recupMediaLivreDB(id);
    }

    public boolean modLivre(int id, String titre, double prix, String etat, int annee, int stock, int idSupport, String isbn, int idEditeur, int idFormatLivre) {
        boolean test = false;
        if (instanceLivre.modMediaDB(id, titre, prix, etat, annee, stock, idSupport)) {
            if (instanceLivre.modMediaLivreDB(id, isbn, idEditeur, idFormatLivre)) {
                test = true;
            }
        }
        return test;
    }

//    public int addLivre(String titre, double prix, String etat, int annee, int stock, int idSupport, String isbn, int idEditeur, int idFormatLivre) {
//        int idMediaAdd;
//        idMediaAdd = instanceLivre.addMediaDB(titre, prix, etat, annee, stock, idSupport);
//        if (idMediaAdd != 0) {
//            instanceLivre.addMediaLivreDB(idMediaAdd, isbn, idEditeur, idFormatLivre);
//        }
//        return idMediaAdd;
//    }
    
        public int addLivre(String titre, double prix, String etat, int annee, int stock, int idSupport, String isbn, int idEditeur, int idFormatLivre) {
        return instanceLivre.addMedialLivreDB(titre, prix, etat, annee, stock, idSupport, isbn, idEditeur, idFormatLivre);
    }

    public boolean supLivre(int id) {
        return instanceLivre.supMediaLivreDB(id);
    }
}
