/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Class.User;
import java.util.ArrayList;

/**
 *
 * @author Panzzer
 */
public class C_User {

    private User instanceUser = new User();

    public C_User() {
    }

    public User getInstanceUser() {
        return instanceUser;
    }

    public boolean verifCompte(String pseudo, String mdp) {
        return instanceUser.verifCompte(pseudo, mdp);
    }

    public ArrayList<User> getListUser() {
        this.instanceUser.recupUserDB();
        return this.instanceUser.getListUser();
    }

    public boolean modifUser(String pseudo, String email, String droit, String mdp, int idUser) {
        return instanceUser.modifUser(pseudo, email, droit, mdp, idUser);
    }

    public boolean addUser(String pseudo, String email, String droit, String mdp) {
        return instanceUser.addUser(pseudo, email, droit, mdp);
    }

    public boolean suppUser(int idUser) {
        return instanceUser.suppUser(idUser);
    }
}
